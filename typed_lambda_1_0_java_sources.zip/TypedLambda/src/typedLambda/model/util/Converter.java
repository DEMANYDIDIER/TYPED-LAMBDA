package typedLambda.model.util;

import typedLambda.common.Literal;
import typedLambda.model.term.Abstraction;
import typedLambda.model.term.Term;
import typedLambda.model.util.exception.NotInNormalFormException;

/*
 * The converter proposes several converters between representations of a lambda term.
 * 
 * Example of classic representation : "λab.ab"
 * Example of De Brujn representation : "λ 2 1"
 */
public interface Converter {

	/*
	 * This converter takes a classic literal representation
	 * 	- in normal form - of a lambda term
	 * 	and returns a tree representation with De Brujn leaves.
	 */
	public Abstraction convertClassicToTree(Literal literal);

	/*
	 * This converter takes a De Brujn literal representation
	 * 	- in normal form - of a lambda term
	 * 	and returns a tree representation with De Brujn leaves.
	 */
	public Term  convertDeBrujnToTree(String literal);
	
	/*
	 * This converter takes a tree representation in normal form of a lambda term
	 * 	and returns a classic literal representation of this lambda term.
	 */
	public Literal convertToLiteral(Abstraction  hand)
			throws NotInNormalFormException;
}
