package typedLambda.model.util.exception.reduce;

import typedLambda.common.LambdaException;

public class CopyNotFoundException extends LambdaException {
	private static final long serialVersionUID = 1L;

	public CopyNotFoundException() {
	}
}
