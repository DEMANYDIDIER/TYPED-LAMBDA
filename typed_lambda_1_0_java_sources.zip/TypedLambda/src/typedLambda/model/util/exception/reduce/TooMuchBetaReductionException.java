package typedLambda.model.util.exception.reduce;

import typedLambda.common.LambdaException;

public final class TooMuchBetaReductionException extends LambdaException {
	private static final long serialVersionUID = 1L;

	public TooMuchBetaReductionException() {
	}
}
