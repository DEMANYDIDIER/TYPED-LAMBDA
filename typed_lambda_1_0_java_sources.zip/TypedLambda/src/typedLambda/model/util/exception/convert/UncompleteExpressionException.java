package typedLambda.model.util.exception.convert;

public final class UncompleteExpressionException
		extends ReadingExpressionException {
	private static final long serialVersionUID = 1L;

	public UncompleteExpressionException(String expression) {
		super(expression);
	}
}
