package typedLambda.model.util.exception.convert;

import java.io.PrintStream;

import typedLambda.common.LambdaException;

public final class LoopException extends LambdaException {
	private static final long serialVersionUID = 1L;

	public final String object;
	public final int index;
	
	public LoopException(String object, int index) {
		this.object = object;
		this.index = index;
	}

	@Override
	public void printContext(PrintStream out) {
		System.out.println("Repeat " + this.object
				+ "[" + String.valueOf(this.index) + "]");
	}
}
