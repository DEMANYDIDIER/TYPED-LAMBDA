package typedLambda.model.util.exception.convert;

public final class TooMutchClosingException extends ReadingExpressionException {
	private static final long serialVersionUID = 1L;

	public TooMutchClosingException(String expression) {
		super(expression);
	}
}
