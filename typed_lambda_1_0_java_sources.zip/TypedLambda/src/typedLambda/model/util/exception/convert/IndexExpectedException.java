package typedLambda.model.util.exception.convert;

public class IndexExpectedException extends ReadingExpressionException {
	private static final long serialVersionUID = 1L;

	public IndexExpectedException(String expression) {
		super(expression);
	}
}
