package typedLambda.model.util.exception;

import typedLambda.common.LambdaException;

public final class NotInNormalFormException extends LambdaException {
	private static final long serialVersionUID = 1L;

	public NotInNormalFormException() {
	}
}
