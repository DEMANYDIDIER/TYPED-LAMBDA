package typedLambda.model.util;

import typedLambda.model.term.Abstraction;
import typedLambda.model.term.Pair;
import typedLambda.model.term.Term;
import typedLambda.model.util.exception.reduce.TooMuchBetaReductionException;

/*
 * The Reducer proposes the beta reduction of a lambda Term in its tree representation.
 * 
 * A limit may be fixed to the count of beta reductions required for a normalization.
 */
public interface Reducer {

	/*
	 * This method duplicates a lambda term.
	 */
	public <T extends Term> T cloneTerm(T container);
	
	/*
	 * This method returns the leftmost redex of a lambda Term if any,
	 * 	null elsewhere.
	 * 
	 * A true redex is a Pair whose the left part is an Abstraction.
	 * A false redex is a Pair whose the right part is An Abstraction.
	 * 
	 * A true redex is involved in beta reduction.
	 * A false redex is involved in Abstraction going up.
	 */
	public Pair leftmostRedex(Term container, boolean isTrueRedex);
	
	/*
	 * This method proposes the beta reduction of a redex within a container.
	 * 
	 * Returns the substitution count.
	 */
	public int reduceRedex(Abstraction container, Pair redex);

	/*
	 * This method proposes the beta reduction of a free redex.
	 * 
	 * Returns the reduced Term.
	 */
	public Term reduceRedex(Pair redex);
	
	/*
	 * This method proposes the normalization of an Abstraction.
	 * 
	 * Normalization includes beta reductions and Abstraction going up.
	 */
	public Normalization normalize(Abstraction container)
			throws TooMuchBetaReductionException;

	/*
	 * This method proposes the normalization of a Pair.
	 * 
	 * Normalization includes beta reductions and Abstraction going up.
	 */
	public Term normalize(Pair container)
			throws TooMuchBetaReductionException;
	
	/*
	 * Returns the characteristics of the last normalization.
	 */
	public Normalization lastNormalization();
}
