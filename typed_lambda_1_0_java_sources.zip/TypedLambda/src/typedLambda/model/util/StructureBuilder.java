package typedLambda.model.util;

import typedLambda.model.term.Abstraction;
import typedLambda.model.term.Term;

/*
 * The StructureBuilder proposes the building of various combinators.
 */
public interface StructureBuilder {

	/*
	 * Returns an Identity combinator.
	 */
	public Abstraction newIdentity();
	
	/*
	 * Returns a boolean combinator.
	 */
	public Abstraction newBoolean(boolean value);
	
	/*
	 * Returns a Church numeral combinator.
	 */
	public Abstraction newNumeral(int n);
	
	/*
	 * Returns a pair of terms.
	 */
	public Abstraction newCouple(Term component1, Term component2);
}
