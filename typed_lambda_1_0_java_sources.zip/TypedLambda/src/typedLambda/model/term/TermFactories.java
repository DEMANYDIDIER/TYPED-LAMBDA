package typedLambda.model.term;

/*
 * Provides an access to the three term factories.
 */
public interface TermFactories {

	/*
	 * Provides an access to the abstractions factory.
	 */
	public TermFactory<Abstraction> getAbstractionFactory();
	
	/*
	 * Provides an access to the pairs factory.
	 */
	public TermFactory<Pair> getPairFactory();
	
	/*
	 * Provides an access to the leaves factory.
	 */
	public TermFactory<Leaf> getLeafFactory();

	/*
	 * Returns the memory size required for storing the terms
	 * 	that wait before next reusing.
	 * 
	 * The unit is a 32 bits word,
	 * 	i.e. the size of an integer or a reference on a usual desk machine.
	 */
	public int getMemorySize();
}
