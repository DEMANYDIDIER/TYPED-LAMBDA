package typedLambda.model.term;

import typedLambda.model.term.exception.ClearFirstException;
import typedLambda.model.term.exception.NotAFreeTermException;

/*
 * An Abstraction object represents an abstraction in lambda calculus.
 */
public interface Abstraction extends Term {

	/*
	 * Returns the body of the abstraction.
	 */
	public Term getBody();
	
	/*
	 * Set the body of the abstraction.
	 * 
	 * The abstraction must have no body.
	 * The body must have no parent.
	 */
	public void setBody(Term body)
			throws ClearFirstException, NotAFreeTermException;

	/*
	 * Breaks the body link.
	 */
	public void clearBody();
}
