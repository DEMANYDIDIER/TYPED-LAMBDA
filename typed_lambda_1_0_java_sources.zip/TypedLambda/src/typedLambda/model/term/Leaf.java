package typedLambda.model.term;

import typedLambda.model.term.exception.AbstractionNotFoundException;

/*
 * A Leaf object represents a variable in lambda calculus.
 */
public interface Leaf extends Term {

	/*
	 * Return the De Bruijn index attached to the variable.
	 */
	public int getDBIndex();
	
	/*
	 * Set the DE Bruijn index attached to the variable.
	 */
	public void setDBIndex(int dBIndex);
	
	/*
	 * If the variable is free then increments the DB index
	 * 	with the given count.
	 */
	public void incrementDBIndexIfFree(int count);
	
	/*
	 * If the variable is free then decrements the DB index.
	 */
	public void decrementDBIndexIfFree();
	
	/*
	 * Returns the bound abstraction, if any.
	 */
	public Abstraction getTarget();
	
	/*
	 * Set the DB index for binding the given Abstraction.
	 * 
	 * Such an abstraction must be accessible.
	 */
	public void setDBIndex(Abstraction target)
		throws AbstractionNotFoundException;
}
