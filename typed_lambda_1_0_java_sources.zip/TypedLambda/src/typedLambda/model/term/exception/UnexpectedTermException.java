package typedLambda.model.term.exception;

import java.io.PrintStream;

import typedLambda.common.LambdaException;

public class UnexpectedTermException extends LambdaException {
	private static final long serialVersionUID = 1L;

	public UnexpectedTermException() {
	}

	@Override
	public void printContext(PrintStream out) {
	}
}
