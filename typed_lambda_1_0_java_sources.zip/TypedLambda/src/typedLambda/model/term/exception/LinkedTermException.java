package typedLambda.model.term.exception;

import typedLambda.common.LambdaException;

public class LinkedTermException extends LambdaException {
	private static final long serialVersionUID = 1L;

	public LinkedTermException() {
	}
}
