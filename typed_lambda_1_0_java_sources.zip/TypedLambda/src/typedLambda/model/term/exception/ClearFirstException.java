package typedLambda.model.term.exception;

import typedLambda.common.LambdaException;

public final class ClearFirstException extends LambdaException {
	private static final long serialVersionUID = 1L;

	public ClearFirstException() {
	}
}
