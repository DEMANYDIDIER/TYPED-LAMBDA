package typedLambda.model.type;

/*
 * A FunctionTypeBase represents a base of FunctionType.
 * 
 * The goal of using such an object is avoiding duplications.
 */
public interface FunctionTypeBase {

	/*
	 * Returns a FunctionType defined by its argument Type and its result Type.
	 * 
	 * Adds this FunctionType to this FunctionTypeBase if not already existing.
	 * Returns the FunctionType existing in the base preferably to a new one.
	 */
	public FunctionType functionType(Type from, Type to);

	/*
	 * Returns the content of this FunctionTypeBase.
	 * 
	 * The array of FunctionType is sorted by Type length.
	 * This is not a total order.
	 */
	public FunctionType[] getContent();
}
