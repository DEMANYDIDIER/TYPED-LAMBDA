package typedLambda.model.type;

/*
 * A FunctionType represents a function Type.
 */
public interface FunctionType extends Type {

	/*
	 * Returns the argument Type of this FunctionType.
	 */
	public Type getFrom();
	
	/*
	 * Returns the result Type of this FunctionType.
	 */
	public Type getTo();

	/*
	 * The AnyFunction Type is the function (AnyType -> AnyType).
	 * 
	 * The symbol of the AnyFunction Type is 'f'.
	 * 
	 * The only known AnyFunction value is the Identity function (λa.a).
	 */
	public boolean isAnyFunctionType();
	
	/*
	 * The BooleanType is the function (AnyType -> AnyFunction).
	 * 
	 * The symbol of the BooleanType is 'b'.
	 * 
	 * BooleanType is the type of the boolean values
	 * 	(true, false) or (yes, no) or (λab.a, λab.b).
	 */
	public boolean isBooleanType();
	
	/*
	 * The NaturalType is the function (AnyFunction -> AnyFunction).
	 * 
	 * The symbol of the NaturalType is 'n'.
	 * 
	 * NaturalType is the type of the natural numbers (1, 2, 3, ...).
	 */
	public boolean isNaturalType();
}
