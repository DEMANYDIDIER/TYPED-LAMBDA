package typedLambda.model.substitute;

import typedLambda.model.term.Pair;

/*
 * A PairSubstitution is a Substitution whose the parent of the substituted Term
 * 	is a Pair.
 */
public interface PairSubstitution extends Substitution {

	/*
	 * Returns the parent Pair of the substituted Term.
	 */
	public Pair getPair();
	
	/*
	 * Set the parent Pair of the substituted Term.
	 */
	public void setPair(Pair pair);
}
