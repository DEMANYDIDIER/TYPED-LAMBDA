package typedLambda.model.substitute;

/*
 * A SubstitutionFactory recycle's substitutions in order to avoiding to making working
 * 	the native Java garbage collector during term beta reduction.
 * 
 * This parameterized interface is declined in
 * 	the SubstitutionFactory<BodySubstitution>,
 * 	the SubstitutionFactory<LeftSubstitution> and
 * 	the SubstitutionFactory<RightSubstitution>.Substitution
 */
public interface SubstitutionFactory<T extends Substitution> {

	/*
	 * Provides a new Substitution.
	 * 
	 * This new Term is either a BodySubstitution,
	 * 	a LeftSubstitution or a RightSubstitution,
	 * 	depending on the parameter T of the interface.
	 */
	public T newSubstitution();

	/*
	 * Returns the given Substitution to the SubstitutionFactory.
	 * 
	 * No reference must be made any more to this Substitution.
	 * In the contrary case, the implementation behavior becomes unpredictable.
	 */
	public void returnSubstitution(T substitution);

	/*
	 * Returns the memory size required for storing the substitutions
	 * 	that wait before next reusing.
	 * 
	 * The unit is a 32 bits word,
	 * 	i.e. the size of an integer or a reference on a usual desk machine.
	 */
	public int getMemorySize();
}
