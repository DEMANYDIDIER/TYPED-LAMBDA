package typedLambda.model.substitute;

import typedLambda.model.term.Abstraction;

/*
 * A BodySubstitution is a Substitution whose the substituted Term
 * 	has the place of a body.
 */
public interface BodySubstitution extends Substitution {

	/*
	 * Returns the parent Abstraction of the substituted Term.
	 */
	public Abstraction getAbstraction();
	
	/*
	 * Set the parent Abstraction of the substituted Term.
	 */
	public void setAbstraction(Abstraction abstraction);
}
