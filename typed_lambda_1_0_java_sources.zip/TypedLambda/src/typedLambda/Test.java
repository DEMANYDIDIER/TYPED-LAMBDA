package typedLambda;

import java.io.PrintStream;

import typedLambda.common.LambdaException;
import typedLambda.common.Literal;
import typedLambda.impl.substitute.BodySubstitutionFactoryImpl;
import typedLambda.impl.substitute.BodySubstitutionImpl;
import typedLambda.impl.substitute.LeftSubstitutionFactoryImpl;
import typedLambda.impl.substitute.LeftSubstitutionImpl;
import typedLambda.impl.substitute.RightSubstitutionFactoryImpl;
import typedLambda.impl.substitute.RightSubstitutionImpl;
import typedLambda.impl.term.AbstractionFactoryImpl;
import typedLambda.impl.term.AbstractionImpl;
import typedLambda.impl.term.LeafFactoryImpl;
import typedLambda.impl.term.LeafImpl;
import typedLambda.impl.term.PairFactoryImpl;
import typedLambda.impl.term.PairImpl;
import typedLambda.impl.term.TermImpl;
import typedLambda.impl.type.FunctionTypeBaseImpl;
import typedLambda.impl.type.FunctionTypeImpl;
import typedLambda.impl.type.TypeImpl;
import typedLambda.impl.util.CollectorImpl;
import typedLambda.impl.util.ConverterImpl;
import typedLambda.impl.util.ReducerImpl;
import typedLambda.impl.util.StructureBuilderImpl;
import typedLambda.impl.util.TypeAssignerImpl;
import typedLambda.model.substitute.BodySubstitution;
import typedLambda.model.substitute.PairSubstitution;
import typedLambda.model.substitute.SubstitutionFactory;
import typedLambda.model.term.Abstraction;
import typedLambda.model.term.Leaf;
import typedLambda.model.term.Pair;
import typedLambda.model.term.Term;
import typedLambda.model.term.TermFactory;
import typedLambda.model.type.FunctionType;
import typedLambda.model.type.FunctionTypeBase;
import typedLambda.model.type.Type;
import typedLambda.model.util.Collector;
import typedLambda.model.util.Converter;
import typedLambda.model.util.Reducer;
import typedLambda.model.util.StructureBuilder;
import typedLambda.model.util.TypeAssigner;
import typedLambda.model.util.exception.NotInNormalFormException;

public class Test {
	
	private static final Object o1 = new Object();
	private static final Object o2 = new Object();
	private static final Object o3 = new Object();
	
	public static final String product = "TypedLambda 1.0 2025-01-18";
	
//	public static final TermFactory<Abstraction> abstractionFactory = AbstractionFactoryImpl.defaultTermFactory;
//	public static final TermFactory<Pair> pairFactory = PairFactoryImpl.defaultTermFactory;
//	public static final TermFactory<Leaf> leafFactory = LeafFactoryImpl.defaultTermFactory;
//	
//	public static final SubstitutionFactory<AbstractionSubstitution> abstractionSubstitutionFactory = AbstractionSubstitutionFactoryImpl.defaultSubstitutionFactory;
//	public static final SubstitutionFactory<PairSubstitution> leftSubstitutionFactory = LeftSubstitutionFactoryImpl.defaultSubstitutionFactory;
//	public static final SubstitutionFactory<PairSubstitution> rightSubstitutionFactory = RightSubstitutionFactoryImpl.defaultSubstitutionFactory;
	
	public static final TermFactory<Abstraction> abstractionFactory = new AbstractionFactoryImpl();
	public static final TermFactory<Pair> pairFactory = new PairFactoryImpl();
	public static final TermFactory<Leaf> leafFactory = new LeafFactoryImpl();

	public static final SubstitutionFactory<BodySubstitution> abstractionSubstitutionFactory = new BodySubstitutionFactoryImpl();
	public static final SubstitutionFactory<PairSubstitution> leftSubstitutionFactory = new LeftSubstitutionFactoryImpl();
	public static final SubstitutionFactory<PairSubstitution> rightSubstitutionFactory = new RightSubstitutionFactoryImpl();
	
	public static void main(String[] args) {
		test();
	}

	public  static final void test() {
		
		Literal[] combinators = new Literal[] {
				Literal.I,
				Literal.K,
				Literal.F,
				Literal.ONE,
				Literal.TWO,
				Literal.TREE,
				Literal.POWER,
				Literal.IF_THEN_ELSE,
				Literal.SUCC,
				Literal.PAIR,
				Literal.FIRST,
				Literal.SECOND,
				Literal.ADD,
				Literal.MULT
		};

		String[] dBCombinators = new String[] {
				DBLiteral.I,
				DBLiteral.K,
				DBLiteral.F,
				DBLiteral.ONE,
				DBLiteral.TWO,
				DBLiteral.TREE,
				DBLiteral.POWER,
				DBLiteral.IF_THEN_ELSE,
				DBLiteral.SUCC,
				DBLiteral.PAIR,
				DBLiteral.FIRST,
				DBLiteral.SECOND,
				DBLiteral.ADD,
				DBLiteral.MULT
		};

		Collector collector = new CollectorImpl();
		StructureBuilder structureBuilder = new StructureBuilderImpl();
		Converter converter = new ConverterImpl();
		Reducer reducer = new ReducerImpl(collector, 1000000000);
		FunctionTypeBase functionBase = new FunctionTypeBaseImpl();
		Type baseType = TypeImpl.ANY_TYPE;
		TypeAssigner typeAssigner =
				new TypeAssignerImpl(functionBase, baseType, converter);
		
		try {
			if (!new AbstractionImpl().isAbstraction())
				throw new LambdaException();
			if (!new PairImpl().isPair())
				throw new LambdaException();
			if (!new LeafImpl().isLeaf())
				throw new LambdaException();
			
			if (!new BodySubstitutionImpl().isBodySubstitution())
				throw new LambdaException();
			if (!new LeftSubstitutionImpl().isLeftSubstitution())
				throw new LambdaException();
			if (!new RightSubstitutionImpl().isRightSubstitution())
				throw new LambdaException();
			
			PrintStream out = System.out;
			
			out.println(product);
			out.println();
			out.println("---- JavaSE-17 signature");
			out.println(o1.hashCode());
			out.println(o2.hashCode());
			out.println(o3.hashCode());
			out.println();
			
			out.println("---- Types");
			out.println("(" + FunctionTypeImpl.FUNC.toString() + ")  ==  "
					+ FunctionTypeImpl.FUNC.toString(true));
			out.println("(" + FunctionTypeImpl.BOOL.toString() + ")  ==  "
					+ FunctionTypeImpl.BOOL.toString(true));
			out.println("(" + FunctionTypeImpl.INT.toString() + ")  ==  "
					+ FunctionTypeImpl.INT.toString(true));
			out.println();
			out.println(new FunctionTypeImpl(FunctionTypeImpl.INT, FunctionTypeImpl.INT).toString(true));
			out.println((new FunctionTypeImpl(TypeImpl.ANY_TYPE, TypeImpl.ANY_TYPE).isSameTypeThan(
					new FunctionTypeImpl(TypeImpl.ANY_TYPE, TypeImpl.ANY_TYPE))));
			out.println();
			
			out.println("---- Sub-Types");
			{
				FunctionType[][] typess = new FunctionType[][] {
					{FunctionTypeImpl.BOOL, FunctionTypeImpl.BOOL},
					{FunctionTypeImpl.BOOL, functionBase.functionType(FunctionTypeImpl.FUNC, TypeImpl.ANY_TYPE)},
					{FunctionTypeImpl.FUNC, FunctionTypeImpl.BOOL},
					{FunctionTypeImpl.BOOL, FunctionTypeImpl.INT},
					{FunctionTypeImpl.FUNC, FunctionTypeImpl.INT}
				};
				for (int k = 0; k < typess.length; k++) {
					FunctionType[] types = typess[k];
					FunctionType type1 = types[0];
					FunctionType type2 = types[1];
					boolean isType1SubOfType2 = type1.isSubTypeOfOrSameTypeThan(type2);
					boolean isType1SameThanType2 = type1.isSameTypeThan(type2);
					boolean isType2SubOfType1 = type2.isSubTypeOfOrSameTypeThan(type1);
					String s1sub2 = isType1SubOfType2 ? "yes" : "no ";
					String s1same2 = isType1SameThanType2 ? "yes" : "no ";
					String s2sub1 = isType2SubOfType1 ? "yes" : "no ";
					StringBuffer sb = new StringBuffer();
					sb.append(type1.toString());
					while (sb.length() < 25)
						sb.append(" ");
					sb.append(type2.toString());
					while (sb.length() < 50)
						sb.append(" ");
					sb.append(s1sub2);
					sb.append("  ");
					sb.append(s1same2);
					sb.append("  ");
					sb.append(s2sub1);
					out.println(sb.toString());
				}
			}
			out.println();
			
			out.println("---- Term convertions");
			for (Literal literal : combinators) {
				Abstraction hand = converter.convertClassicToTree(literal);
				Literal literal2 = converter.convertToLiteral(hand);
				out.println(literal.toString()
						+ "  ->  " + hand.toDeBruijnString()
						+ "  ->  " + literal2);
			}
			for (String dBLiteral : dBCombinators) {
				Term term =  converter.convertDeBrujnToTree(dBLiteral);
				out.println(dBLiteral + "  ->  " + term.toDeBruijnString());
			}
			for (String dBLiteral : new String[] {"(λ 1) λ 1", "λ 1 λ 1", "λ (1 λ 1)"}) {
				Term term =  converter.convertDeBrujnToTree(dBLiteral);
				out.println(dBLiteral + "  ->  " + term.toDeBruijnString());
			}
			out.println();
			
			out.println("---- Type assignment");
			{
				Literal literal = new Literal(1, "aa");
				Abstraction hand = converter.convertClassicToTree(literal);
				if (typeAssigner.assignType(hand) == null)
					out.println("UntypedTermException");
			}
			for (Literal literal : combinators) {
				Abstraction hand = converter.convertClassicToTree(literal);
				FunctionType functionType = typeAssigner.assignType(hand);
				out.println(literal.toString() + " : [" + functionType.getFrom().toString(true) + "] -> ["
					+ functionType.getTo().toString(true) + "]");
			}
			for (String ch : new String[] {"abc", "abcd"}) {
				Literal literal = new Literal(ch.length(), ch);
				Abstraction hand = converter.convertClassicToTree(literal);
				FunctionType functionType = typeAssigner.assignType(hand);
				out.println(literal.toString() + " : [" + functionType.getFrom().toString(true) + "] -> ["
						+ functionType.getTo().toString(true) + "]");
			}
			{
				FunctionType[] functionTypes = functionBase.getContent();
				for (FunctionType functionType : functionTypes)
					out.println(functionType.toString(true));
				out.println(((FunctionTypeBaseImpl) functionBase).repartition());
			}
			out.println();
			
			out.println("---- Reducing");
			{
				String dBLiteral = "(λ λ 4 2 (λ 1 3)) (λ 5 1)";
				Pair pair = (Pair) converter.convertDeBrujnToTree(dBLiteral);
				out.println(pair.toDeBruijnString());
				Term term = reducer.reduceRedex(pair);
				out.println(" =β=> " + term.toDeBruijnString());
				collector.returnArgumentToFactory(term);
			}
			for (String dBLiteral : dBCombinators) {
				Abstraction term = (Abstraction) converter.convertDeBrujnToTree(dBLiteral);
				Abstraction copy = (Abstraction) reducer.cloneTerm(term);
				out.println(term.toDeBruijnString() + " = " + copy.toDeBruijnString());
				collector.returnArgumentToFactory(term);
				collector.returnArgumentToFactory(copy);
			}
			{
				String dBLiteral = "(λ λ 4 2 (λ 1 3)) (λ 5 1)";
				Term term = converter.convertDeBrujnToTree(dBLiteral);
				Term copy = reducer.cloneTerm(term);
				out.println(term.toDeBruijnString() + " = " + copy.toDeBruijnString());
				collector.returnArgumentToFactory(term);
				collector.returnArgumentToFactory(copy);
			}
			for (int n = 8; n <= 12; n++) {
				out.println();
				Term term1 = structureBuilder.newNumeral(n);
				Term term2 = structureBuilder.newNumeral(2);
				Pair pair = pairFactory.newTerm();
				pair.setLeft(term1);
				pair.setRight(term2);
				out.println(pair.toDeBruijnString());
				Chrono chrono = new Chrono();
				chrono.setT0();
				Term result = reducer.normalize(pair);
				chrono.setT1();
				out.println(" =β=> "
						+ Numeric.toDecimalAndBinaryAndHexa((Abstraction) result)
						+ " using " + chrono.elapsed()
						+ " for " + reducer.lastNormalization().toString());
				collector.returnArgumentToFactory(result);
			}
			out.println("Terms(int) " + String.valueOf(TermImpl.termFactories.getMemorySize()));
			out.println();
			
			out.println("---- Arithmetic");
			{
				String[][] tests = new String[][] {
					new String[] {"+1", DBLiteral.ADD, DBLiteral.ONE},
					new String[] {"+2", DBLiteral.ADD, DBLiteral.TWO},
					new String[] {"+3", DBLiteral.ADD, DBLiteral.TREE},
					new String[] {"*1", DBLiteral.MULT, DBLiteral.ONE},
					new String[] {"*2", DBLiteral.MULT, DBLiteral.TWO},
					new String[] {"*3", DBLiteral.MULT, DBLiteral.TREE}
				};
				for (int k = 0; k < tests.length; k++) {
					String[] test = tests[k];
					String name = test[0];
					String operatorLiteral = test[1];
					String numeralLiteral = test[2];
					Abstraction operator = (Abstraction) converter.convertDeBrujnToTree(operatorLiteral);
					Abstraction numeral = (Abstraction) converter.convertDeBrujnToTree(numeralLiteral);
					Pair pair = pairFactory.newTerm();
					pair.setLeft(operator);
					pair.setRight(numeral);
					Abstraction result = (Abstraction) reducer.normalize(pair);
					Literal resultLiteral = converter.convertToLiteral(result);
					String resultDBLiteral = result.toDeBruijnString();
					Type type = typeAssigner.assignType(result);
					collector.returnArgumentToFactory(result);
					out.println(name + " = " + resultLiteral + " == " + resultDBLiteral + " : " + type.toString(true));
				}
				out.println();
				
				out.println("---- Couples");
				try {
					Abstraction couple = structureBuilder.newCouple(
							structureBuilder.newIdentity(),
							structureBuilder.newIdentity());
					Type type = typeAssigner.assignType(couple);
					collector.returnArgumentToFactory(couple);
					out.println(type.toString());
				} catch (NotInNormalFormException e) {
					out.println("NotInNormalFormException");
				}
				try {
					Object[][] coupleTests = new Object[][] {
						new Object[] {"<I,I>",
								structureBuilder.newIdentity(),
								structureBuilder.newIdentity()},
						new Object[] {"<K,K>",
								structureBuilder.newBoolean(true),
								structureBuilder.newBoolean(true)},
						new Object[] {"<F,F>",
								structureBuilder.newBoolean(false),
								structureBuilder.newBoolean(false)},
						new Object[] {"<1,1>",
								structureBuilder.newNumeral(1),
								structureBuilder.newNumeral(1)},
						new Object[] {"<2,2>",
								structureBuilder.newNumeral(2),
								structureBuilder.newNumeral(2)},
						new Object[] {"<^,^>",
								converter.convertDeBrujnToTree(DBLiteral.POWER),
								converter.convertDeBrujnToTree(DBLiteral.POWER)},
						new Object[] {"<+,+>",
								converter.convertDeBrujnToTree(DBLiteral.ADD),
								converter.convertDeBrujnToTree(DBLiteral.ADD)},
						new Object[] {"<*,*>",
								converter.convertDeBrujnToTree(DBLiteral.MULT),
								converter.convertDeBrujnToTree(DBLiteral.MULT)}};
								
					for (Object[] coupleTest : coupleTests) {
						String name = (String) coupleTest[0];
						Abstraction component1 = (Abstraction) coupleTest[1];
						Abstraction component2 = (Abstraction) coupleTest[2];
						
						Abstraction couple = structureBuilder.newCouple(component1, component2);
						reducer.normalize(couple);
						
						Literal literal = converter.convertToLiteral(couple);
						FunctionType functionType = typeAssigner.assignType(couple);
						collector.returnArgumentToFactory(couple);
						out.println(name + " =β= " + literal.toString() + " : [" + functionType.getFrom().toString(true)
								+ "] -> [" + functionType.getTo().toString(true) + "]");
					}
				} catch (NotInNormalFormException e) {
					out.println("NotInNormalFormException");
				}
			}
			out.println();
			
			out.println("---- Type assignment reasoning");
			{
				Abstraction abstraction = structureBuilder.newCouple(
						structureBuilder.newNumeral(1),
						structureBuilder.newNumeral(1));
				reducer.normalize(abstraction);
				out.println(abstraction.toString());
				typeAssigner.assignType(abstraction, out);
			}
			out.println();
			
			out.println("---- TypedLambda demonstration page end");
			out.println();
			{
				StringBuffer sb = new StringBuffer();
				for (int k = 945; k < 970; k++)
					sb.append((char) k);
				out.println(sb.toString());
			}
		} catch (LambdaException le) {
			le.printContext(System.out);
			le.printStackTrace(System.out);
		}
	}
}
