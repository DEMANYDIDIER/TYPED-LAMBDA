package typedLambda.impl.type;

import java.util.Arrays;
import java.util.Comparator;

import typedLambda.model.type.FunctionType;
import typedLambda.model.type.Type;
import typedLambda.model.type.FunctionTypeBase;

public class FunctionTypeBaseImpl implements FunctionTypeBase {
	public static final int anyTypeSignature = 4656583;
	
	public static final int functionSignature(
			int fromSignature, int toSignature) {
		return 8665541 + 47 * fromSignature + 59 * toSignature;
	}
	
	public static final int typeSignature(Type type) {
		if (type.isAnyType())
			return anyTypeSignature;
		
		FunctionType functionType = (FunctionType) type;
		return functionSignature(
				typeSignature(functionType.getFrom()),
				typeSignature(functionType.getTo()));
	}
	
	public static final int getTypeOrder(Type type) {
		if (type.isAnyType())
			return 1;
		FunctionType functionType = (FunctionType) type;
		return getTypeOrder(functionType.getFrom()) + getTypeOrder(functionType.getTo());
	}
	
	private final FunctionTypeImpl[] functionTypes;
	private boolean isInitialisationAchieved = false;
	
	public FunctionTypeBaseImpl(int length) {
		if (length < 1 ||  (length & (length - 1)) != 0)// power of 2
				throw new IllegalArgumentException();
		
		this.functionTypes = new FunctionTypeImpl[length];
		Arrays.fill(this.functionTypes, null);
	}
	
	public FunctionTypeBaseImpl() {
		this(32);
	}
	
	public final int indexSize(int index) {
		int count = 0;
		FunctionTypeImpl functionType = this.functionTypes[index];
		while (functionType != null) {
			count++;
			functionType = functionType.previous;
		}
		return count;
	}
	
	public final String repartition() {
		StringBuffer sb = new StringBuffer();
		for (int k = 0; k < this.functionTypes.length; k++) {
			sb.append(this.indexSize(k));
			sb.append(" ");
		}
		return sb.toString();
	}

	private final int functionTypeIndex(int functionTypeSignature) {
		return functionTypeSignature & (this.functionTypes.length - 1);
	}
	
	private void predefinedFunctionType(FunctionTypeImpl functionType) {
		int signature = functionSignature(
				typeSignature(functionType.getFrom()),
				typeSignature(functionType.getTo()));
		int index = functionTypeIndex(signature);
		if (this.functionTypes[index] != null)
			throw new IllegalStateException();
		this.functionTypes[index] = functionType;
	}
	
	private void predefinedFunctionTypes() {
		this.predefinedFunctionType(FunctionTypeImpl.FUNC);
		this.predefinedFunctionType(FunctionTypeImpl.BOOL);
		this.predefinedFunctionType(FunctionTypeImpl.INT);
		this.isInitialisationAchieved = true;;
	}
	
	@Override
	public final FunctionType functionType(Type from, Type to) {
		if (!this.isInitialisationAchieved)
			this.predefinedFunctionTypes();
		
		int signature = functionSignature(typeSignature(from), typeSignature(to));
		int index = functionTypeIndex(signature);
		FunctionTypeImpl functionType = this.functionTypes[index];
		if (functionType == null) {
			functionType = new FunctionTypeImpl(from, to);
			this.functionTypes[index] = functionType;
			return functionType;
		}
		while (true) {
			if ((typeSignature(functionType) == signature)
					&& (functionType.getFrom().isSameTypeThan(from))
					&& (functionType.getTo().isSameTypeThan(to)))
				return functionType;
			functionType = functionType.previous;
			if (functionType == null)
				break;
		}
		functionType = new FunctionTypeImpl(from, to);
		functionType.previous = this.functionTypes[index];
		this.functionTypes[index] = functionType;
		return functionType;
	}
	
	@Override
	public FunctionType[] getContent() {
		if (!this.isInitialisationAchieved)
			this.predefinedFunctionTypes();
		
		int count = 0;
		for (int k = 0; k < this.functionTypes.length; k++) {
			FunctionTypeImpl functionType = this.functionTypes[k];
			while (functionType != null) {
				count++;
				functionType = functionType.previous;
			}
		}
		FunctionTypeImpl[] content = new FunctionTypeImpl[count];
		count = 0;
		for (int k = 0; k < this.functionTypes.length; k++) {
			FunctionTypeImpl functionType = this.functionTypes[k];
			while (functionType != null) {
				content[count++] = functionType;
				functionType = functionType.previous;
			}
		}
		Arrays.sort(content, 0, content.length, new Comparator<FunctionTypeImpl>() {
			@Override
			public int compare(FunctionTypeImpl ft1, FunctionTypeImpl ft2) {
				int f1Order = getTypeOrder(ft1);
				int f2Order = getTypeOrder(ft2);
				return f1Order - f2Order;
			}});
		
		return content;
	}
}
