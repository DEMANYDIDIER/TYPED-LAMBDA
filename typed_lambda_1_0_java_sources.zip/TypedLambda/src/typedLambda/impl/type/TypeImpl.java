package typedLambda.impl.type;

import typedLambda.model.type.Type;

public class TypeImpl implements Type {

	public static final TypeImpl ANY_TYPE = new TypeImpl('o');

	char symbol;
	
	public TypeImpl(char symbol) {
		this.symbol = symbol;
	}

	@Override
	public final char getSymbol() {
		return this.symbol;
	}
	
	@Override
	public final boolean isPredefined() {
		return this.symbol != (char) 0;
	}

	@Override
	public boolean isAnyType() {
		return true;
	}

	@Override
	public boolean isFunctionType() {
		return false;
	}

	@Override
	public boolean isSameTypeThan(Type type) {
		return type.isAnyType();
	}

	@Override
	public boolean isSubTypeOfOrSameTypeThan(Type type) {
		return type.isAnyType();
	}
	
	@Override
	public int length() {
		return 1;
	}
	
	@Override
	public String toString(boolean isCompact) {
		return "o";
	}

	@Override
	public String toString() {
		return this.toString(false);
	}
}
