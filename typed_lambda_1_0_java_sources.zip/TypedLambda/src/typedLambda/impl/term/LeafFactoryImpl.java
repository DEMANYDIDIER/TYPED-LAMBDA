package typedLambda.impl.term;

import typedLambda.model.term.Leaf;
import typedLambda.model.term.TermFactory;
import typedLambda.model.term.exception.NotAFreeTermException;

public class LeafFactoryImpl extends TermFactoryImpl<Leaf> {
	public static final TermFactory<Leaf> defaultTermFactory = new TermFactory<Leaf>() {

		@Override
		public Leaf newTerm() {
			return new LeafImpl();
		}

		@Override
		public void returnTerm(Leaf term) throws NotAFreeTermException {
		}

		@Override
		public int getMemorySize() {
			return 0;
		}
	};

	@Override
	TermImpl defaultNewTerm() {
		return new LeafImpl();
	}

	@Override
	public final int termMemorySize() {
		return LeafImpl.leafSize;
	}
}
