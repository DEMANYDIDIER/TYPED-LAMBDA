package typedLambda.impl.term;

import typedLambda.model.term.Pair;
import typedLambda.model.term.TermFactory;
import typedLambda.model.term.exception.NotAFreeTermException;

public class PairFactoryImpl extends TermFactoryImpl<Pair> {
	public static final TermFactory<Pair> defaultTermFactory = new TermFactory<Pair>() {

		@Override
		public Pair newTerm() {
			return new PairImpl();
		}

		@Override
		public void returnTerm(Pair term) throws NotAFreeTermException {
		}

		@Override
		public int getMemorySize() {
			return 0;
		}
	};

	@Override
	TermImpl defaultNewTerm() {
		return new PairImpl();
	}

	@Override
	public final int termMemorySize() {
		return PairImpl.pairSize;
	}
}
