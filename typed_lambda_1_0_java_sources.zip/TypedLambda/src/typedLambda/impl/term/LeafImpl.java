package typedLambda.impl.term;

import typedLambda.model.term.Abstraction;
import typedLambda.model.term.Leaf;
import typedLambda.model.term.Term;
import typedLambda.model.term.exception.AbstractionNotFoundException;

public final class LeafImpl extends TermImpl implements Leaf {
	public static final int leafSize = 6;
	
	private int dBIndex = 1;
	
	public LeafImpl() {
	}

	@Override
	public boolean isLeaf() {
		return true;
	}

	@Override
	public boolean isAbstraction() {
		return false;
	}

	@Override
	public boolean isPair() {
		return false;
	}

	@Override
	public int getDBIndex() {
		return this.dBIndex;
	}

	@Override
	public void setDBIndex(int dBIndex) {
		if (dBIndex < 1)
			throw new IllegalArgumentException();
		
		if (this.reusePort != null)
			throw new IllegalStateException();

		this.dBIndex = dBIndex;
	}

	@Override
	public void incrementDBIndexIfFree(int count) {
		if (count < 1)
			throw new IllegalArgumentException();
		
		if (this.getTarget() == null)
			this.dBIndex += count;
	}

	@Override
	public void decrementDBIndexIfFree() {
		if (this.getTarget() == null)
			if (this.dBIndex > 1)
				this.dBIndex--;
			else
				throw new IllegalStateException();
	}

	@Override
	public void clear() {
		this.setDBIndex(1);
	}
	
	@Override
	public boolean isBroken() {
		return false;
	}

	@Override
	public final Abstraction getTarget() {
		Term term = this;
		int dBIndex = this.getDBIndex();
		
		while (true) {
			term = term.getParent();
			if (term == null)
				return null;
			
			if (term.isAbstraction())
				if (dBIndex-- == 1)
					break;
		}
		
		return (Abstraction) term;
	}

	@Override
	public final void setDBIndex(Abstraction target) {
		Term term = this;
		int dBIndex = 1;
		
		while (true) {
			term = term.getParent();
			if (term == null)
				throw new AbstractionNotFoundException();
			
			if (term.isAbstraction()) {
				if (term == target)
					break;
				dBIndex++;
			}
		}
		
		this.setDBIndex(dBIndex);
	}

	@Override
	public int hashCode() {
		return 357;
	}
	
	@Override
	public String toDeBruijnString() {
		return String.valueOf(this.dBIndex);
	}
	
	@Override
	public String toDetailedDeBruijnString() {
		return String.valueOf(this.dBIndex);
	}
}
