package typedLambda.impl.term;

import typedLambda.model.term.Term;
import typedLambda.model.term.TermFactories;

public abstract class TermImpl implements Term {

	public static final TermFactories termFactories = new TermFactoriesImpl();
	
	TermImpl parent = null;
	TermImpl reusePort = null;
	
	public TermImpl() {
	}
	
	@Override
	public Term getParent() {
		return this.parent;
	}

	@Override
	public boolean isCleared() {
		return true;
	}

	@Override
	public final String toString() {
		String superString = super.toString();
		int pos = superString.indexOf('@');
		String address = superString.substring(pos);
		return this.toDetailedDeBruijnString() + address;
	}
}
