package typedLambda.impl.term;

import typedLambda.model.term.Term;
import typedLambda.model.term.TermFactory;
import typedLambda.model.term.exception.LinkedTermException;
import typedLambda.model.term.exception.NotAFreeTermException;

public abstract class TermFactoryImpl<T extends Term> implements TermFactory<T> {
	private final TermImpl reusePort = this.defaultNewTerm();
	private TermImpl reuseTopTerm;

	public TermFactoryImpl() {
		this.reuseTopTerm = this.reusePort;
	}

	@SuppressWarnings("unchecked")
	@Override
	public T newTerm() {
		TermImpl term = null;
		
		synchronized (this.reusePort) {
			if (this.reuseTopTerm != this.reusePort) {
				term = this.reuseTopTerm;
				this.reuseTopTerm =
						this.reuseTopTerm.reusePort;
			}
		}
		if (term == null)
			return (T) this.defaultNewTerm();
		
		term.reusePort = null;
		return (T) term;
	}

	@Override
	public void returnTerm(T term)
			throws NotAFreeTermException, LinkedTermException {
		
		if (term == null)
			throw new IllegalArgumentException();
		if (!term.isCleared())
			throw new LinkedTermException();
		if (term.getParent() != null)
			throw new NotAFreeTermException();
		
		TermImpl termImpl = (TermImpl) term;
		
		if (termImpl.reusePort != null)
			throw new Error("Term already returned");
		
		synchronized (this.reusePort) {
			termImpl.reusePort = this.reuseTopTerm;
			this.reuseTopTerm = termImpl;
		}
	}
	
	abstract TermImpl defaultNewTerm();
	
	public abstract int termMemorySize();
	
	public final int termCount() {
		TermImpl term = this.reuseTopTerm;
		int termCount = 1;
		while (term != this.reusePort) {
			termCount++;
			term = term.reusePort;
		}
		return termCount;
	}
	
	public int getMemorySize() {
		return termCount() * termMemorySize();
	}
}
