package typedLambda.impl.substitute;

import typedLambda.model.substitute.PairSubstitution;
import typedLambda.model.substitute.SubstitutionFactory;

public final class LeftSubstitutionFactoryImpl extends PairSubstitutionFactoryImpl {
	public static final SubstitutionFactory<PairSubstitution> defaultSubstitutionFactory = new SubstitutionFactory<PairSubstitution>() {

		@Override
		public PairSubstitution newSubstitution() {
			return new LeftSubstitutionImpl();
		}

		@Override
		public void returnSubstitution(PairSubstitution substitution) {
		}

		@Override
		public int getMemorySize() {
			return 0;
		}
	};

	public LeftSubstitutionFactoryImpl() {
	}

	@Override
	SubstitutionImpl defaultNewSubstitution() {
		return new LeftSubstitutionImpl();
	}
}
