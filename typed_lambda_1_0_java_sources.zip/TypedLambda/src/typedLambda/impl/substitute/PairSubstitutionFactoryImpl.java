package typedLambda.impl.substitute;

import typedLambda.model.substitute.PairSubstitution;

public abstract class PairSubstitutionFactoryImpl extends SubstitutionFactoryImpl<PairSubstitution> {

	public PairSubstitutionFactoryImpl() {
	}

	@Override
	public void returnSubstitution(PairSubstitution substitution) {
	}

	@Override
	public int substitutionMemorySize() {
		return PairSubstitutionImpl.pairSubstitutionSize;
	}
}
