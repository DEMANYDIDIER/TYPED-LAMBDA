package typedLambda.impl.substitute;

import typedLambda.model.substitute.PairSubstitution;
import typedLambda.model.substitute.SubstitutionFactory;

public final class RightSubstitutionFactoryImpl extends PairSubstitutionFactoryImpl {
	public static final SubstitutionFactory<PairSubstitution> defaultSubstitutionFactory = new SubstitutionFactory<PairSubstitution>() {

		@Override
		public PairSubstitution newSubstitution() {
			return new RightSubstitutionImpl();
		}

		@Override
		public void returnSubstitution(PairSubstitution substitution) {
		}

		@Override
		public int getMemorySize() {
			return 0;
		}
	};

	public RightSubstitutionFactoryImpl() {
	}

	@Override
	SubstitutionImpl defaultNewSubstitution() {
		return new RightSubstitutionImpl();
	}
}
