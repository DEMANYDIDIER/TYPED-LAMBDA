package typedLambda.impl.substitute;

import typedLambda.model.substitute.PairSubstitution;
import typedLambda.model.term.Pair;
import typedLambda.model.term.Term;

public abstract class PairSubstitutionImpl
		extends SubstitutionImpl implements PairSubstitution {
	public static final int pairSubstitutionSize = 6;
	
	Pair pair;

	public PairSubstitutionImpl() {
		super();
	}

	@Override
	public final boolean isNull() {
		return this.pair == null;
	}
	
	@Override
	public final void clear() {
		super.clear();
		this.pair = null;
	}

	@Override
	public final Term getParentTerm() {
		return this.pair;
	}

	@Override
	public final Pair getPair() {
		return this.pair;
	}
	
	@Override
	public final void setPair(Pair pair) {
		if (this.pair != null)
			throw new IllegalStateException();
		this.pair = pair;
	}
}
