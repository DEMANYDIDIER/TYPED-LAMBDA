package typedLambda.impl.substitute;

import typedLambda.model.term.Term;

public final class LeftSubstitutionImpl extends PairSubstitutionImpl {

	public LeftSubstitutionImpl() {
	}

	@Override
	public boolean isLeftSubstitution() {
		return true;
	}

	@Override
	public void substituteBy(Term term) {
		this.pair.setLeft(term);
	}
}
