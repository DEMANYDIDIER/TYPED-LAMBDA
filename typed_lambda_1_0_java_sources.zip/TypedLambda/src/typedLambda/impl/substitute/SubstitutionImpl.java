package typedLambda.impl.substitute;

import typedLambda.model.substitute.Substitution;
import typedLambda.model.substitute.SubstitutionFactories;
import typedLambda.model.term.Term;

public class SubstitutionImpl implements Substitution {
	
	public static final SubstitutionFactories substitutionFactories =
			new SubstitutionFactoriesImpl();

	private SubstitutionImpl previous = null;
	public SubstitutionImpl reusePort = null;
	
	public SubstitutionImpl() {
	}

	@Override
	public boolean isNull() {
		return true;
	}
	
	@Override
	public boolean isBodySubstitution() {
		return false;
	}

	@Override
	public boolean isLeftSubstitution() {
		return false;
	}

	@Override
	public boolean isRightSubstitution() {
		return false;
	}

	@Override
	public void clear() {
		this.previous = null;
	}

	@Override
	public final Substitution getPrevious() {
		return this.previous;
	}
	
	@Override
	public final void setPrevious(Substitution previous) {
		this.previous = (SubstitutionImpl) previous;
	}

	@Override
	public Term getParentTerm() {
		return null;
	}

	@Override
	public final int bindersCount() {
		
		int count = 0;
		
		Term term = this.getParentTerm();

		while (true) {
			if (term.isAbstraction())
				count++;
			term = term.getParent();
			if (term == null)
				break;
		}	
		return count;
	}

	@Override
	public void substituteBy(Term term) {
	}
}
