package typedLambda.impl.substitute;

import typedLambda.model.term.Term;

public final class RightSubstitutionImpl extends PairSubstitutionImpl {

	public RightSubstitutionImpl() {
	}

	@Override
	public boolean isRightSubstitution() {
		return true;
	}

	@Override
	public void substituteBy(Term term) {
		this.pair.setRight(term);
	}
}
