package typedLambda.impl.substitute;

import typedLambda.model.substitute.BodySubstitution;
import typedLambda.model.substitute.SubstitutionFactory;

public final class BodySubstitutionFactoryImpl extends SubstitutionFactoryImpl<BodySubstitution> {
	
	public static SubstitutionFactory<BodySubstitution> defaultSubstitutionFactory = new SubstitutionFactory<BodySubstitution>() {

		@Override
		public BodySubstitution newSubstitution() {
			return new BodySubstitutionImpl();
		}

		@Override
		public void returnSubstitution(BodySubstitution substitution) {
		}

		@Override
		public int getMemorySize() {
			return 0;
		}
	};
	
	public BodySubstitutionFactoryImpl() {
	}

	@Override
	SubstitutionImpl defaultNewSubstitution() {
		return new BodySubstitutionImpl();
	}

	@Override
	public final int substitutionMemorySize() {
		return BodySubstitutionImpl.abstractionSubstitutionSize;
	}
}
