package typedLambda.impl.substitute;

import typedLambda.model.substitute.Substitution;
import typedLambda.model.substitute.SubstitutionFactory;

public abstract class SubstitutionFactoryImpl<T extends Substitution>
		implements SubstitutionFactory<T> {
	
	private final SubstitutionImpl reusePort = this.defaultNewSubstitution();
	private SubstitutionImpl reuseTopSubstitution;

	public SubstitutionFactoryImpl() {
		this.reuseTopSubstitution = this.reusePort;
	}

	@SuppressWarnings("unchecked")
	@Override
	public T newSubstitution() {
		SubstitutionImpl substitution = null;
		
		synchronized (this.reusePort) {
			if (this.reuseTopSubstitution != this.reusePort) {
				substitution = this.reuseTopSubstitution;
				this.reuseTopSubstitution =
						this.reuseTopSubstitution.reusePort;
			}
		}
		if (substitution == null)
			return (T) this.defaultNewSubstitution();
		
		substitution.reusePort = null;
		return (T) substitution;
	}

	@Override
	public void returnSubstitution(Substitution substitution) {
		if (substitution == null)
			throw new IllegalArgumentException();
		if (((SubstitutionImpl) substitution).reusePort != null)
			throw new Error("Substitution already returned");
			
		synchronized (this.reusePort) {
			((SubstitutionImpl) substitution).reusePort = this.reuseTopSubstitution;
			this.reuseTopSubstitution = (SubstitutionImpl) substitution;
		}
	}
	
	abstract SubstitutionImpl defaultNewSubstitution();
	
	public abstract int substitutionMemorySize();
	
	public final int substitutionCount() {
		SubstitutionImpl substitution = this.reuseTopSubstitution;
		int substitutionCount = 1;
		while (substitution != this.reusePort) {
			substitutionCount++;
			substitution = substitution.reusePort;
		}
		return substitutionCount;
	}

	public final int getMemorySize() {
		return substitutionCount() * substitutionMemorySize();
	}
}
