package typedLambda.impl.util;

import java.io.PrintStream;
import java.util.Arrays;

import typedLambda.model.term.Abstraction;
import typedLambda.model.term.Leaf;
import typedLambda.model.term.Pair;
import typedLambda.model.term.Term;
import typedLambda.model.term.exception.UnexpectedTermException;
import typedLambda.model.type.FunctionType;
import typedLambda.model.type.FunctionTypeBase;
import typedLambda.model.type.Type;
import typedLambda.model.type.exception.UntypedTermException;
import typedLambda.model.util.Inferencer;
import typedLambda.model.util.exception.NotInNormalFormException;

public final class InferencerImpl implements Inferencer {
	static final boolean TRACE = false;
	
	private static final Abstraction[] abstractions(Abstraction hand) {
		
		int abstractionCount = 0;
		Term term = hand;
		
		while (term.isAbstraction()) {
			abstractionCount++;
			Abstraction abstraction =(Abstraction) term;
			term = abstraction.getBody();
		}
		
		Abstraction[] abstractions = new Abstraction[abstractionCount];
		
		term = hand;
		int abstractionIndex = 0;
		
		while (term.isAbstraction()) {
			Abstraction abstraction =(Abstraction) term;
			abstractions[abstractionIndex++] = abstraction;
			term = abstraction.getBody();
		}
		return abstractions;
	}

	private static final int countPairs(Term term) {
		if (term.isPair()) {
			Pair pair = (Pair) term;
			return  1 + countPairs(pair.getLeft())
				+ countPairs(pair.getRight());
		} else
			return 0;
	}

	private static final int addPairs(
			Pair[] pairs, int pairIndex, Term term) {
		if (term.isPair()) {
			Pair pair = (Pair) term;
			pairIndex = addPairs(pairs, pairIndex, pair.getLeft());
			pairIndex = addPairs(pairs, pairIndex, pair.getRight());
			pairs[pairIndex++] = pair;
		}
		return pairIndex;
	}

	private static final int addLeaves(
			Leaf[] leaves, int leafIndex, Term term) {
		if (term.isLeaf())
			leaves[leafIndex++] = (Leaf) term;
		else if (term.isPair()) {
			Pair pair = (Pair) term;
			leafIndex = addLeaves(leaves, leafIndex, pair.getLeft());
			leafIndex = addLeaves(leaves, leafIndex, pair.getRight());
		} else
			throw new NotInNormalFormException();
		return leafIndex;
	}

	private final FunctionTypeBase functionBase;
	private final Type baseType;
	private final PrintStream reasoning;
	private final boolean isCompact;
	
	private final Abstraction[] abstractions;
	private final Leaf[] leaves;
	private final Pair[] pairs;
	private final int nodeCount;
	private final Type[] nodeTypes;
	private final FunctionType[] newNodeTypes;
	private final boolean[] updatedNodeTypes;
	private final boolean[] lastUpdatedNodeTypes;
	
	public InferencerImpl(FunctionTypeBase functionBase, Type baseType,
			Abstraction hand, PrintStream reasoning,
			boolean isCompactString) {
		if (functionBase == null || hand == null)
			throw new IllegalArgumentException();
		
		this.functionBase = functionBase;
		this.baseType = baseType;
		this.reasoning = reasoning;
		this.isCompact = isCompactString;
		
		this.abstractions = abstractions(hand);
		Term treeRoot =
				this.abstractions[this.abstractions.length - 1].getBody();
		int pairCount = countPairs(treeRoot);
		nodeCount = this.abstractions.length + pairCount;
		
		this.leaves = new Leaf[pairCount + 1];
		addLeaves(this.leaves, 0, treeRoot);
		
		this.pairs = new Pair[pairCount];
		addPairs(this.pairs, 0, treeRoot);
		
		this.nodeTypes = new Type[nodeCount];
		Arrays.fill(this.nodeTypes, baseType);
		
		this.newNodeTypes = new FunctionType[nodeCount];
		Arrays.fill(this.newNodeTypes, null);
		
		this.updatedNodeTypes = new boolean[nodeCount];
		Arrays.fill(this.updatedNodeTypes, false);
		
		this.lastUpdatedNodeTypes = new boolean[nodeCount];
		Arrays.fill(this.lastUpdatedNodeTypes, false);
		
		if (reasoning != null) {
			this.reasoning.println("abstractions naming");
			for (int k = 0; k < abstractions.length; k++) {
				Abstraction abstraction = abstractions[k];
				reasoning.println(this.getNodeId(this.fromAbstractionToNodeIndex(k))
						+ " = " + this.getTermId(abstraction)
						+ " = " + abstraction.toDetailedDeBruijnString());
			}
			this.reasoning.println("leaves naming");
			for (int k = 0; k < this.leaves.length; k++) {
				Leaf leaf = this.leaves[k];
				Abstraction target = leaf.getTarget();
				reasoning.println("L" + String.valueOf(k)
				+ " -> " + this.getTermId(target));
			}
			this.reasoning.println("applications naming");
			for (int k = 0; k < pairs.length; k++) {
				Pair pair = pairs[k];
				Term function = pair.getLeft();
				Term argument = pair.getRight();
				reasoning.println(this.getNodeId(this.fromPairToNodeIndex(k))
						+ " = " + this.getTermId(pair)
						+ " = [" + this.getTermId(function) + " " + this.getTermId(argument)
						+ "] = " + pair.toDetailedDeBruijnString());
			}
		}
	}

	private int getAbstractionIndex(Abstraction abstraction) {
		for (int index = 0; index < this.abstractions.length; index++)
			if (this.abstractions[index] == abstraction)
				return index;
		return -1;
	}

	private int getLeafIndex(Leaf leaf) {
		for (int index = 0; index < this.leaves.length; index++)
			if (this.leaves[index] == leaf)
				return index;
		return -1;
	}

	private int getPairIndex(Pair pair) {
		for (int index = 0; index < this.pairs.length; index++)
			if (this.pairs[index] == pair)
				return index;
		return -1;
	}

	private int fromAbstractionToNodeIndex(int abstractionIndex) {
		return abstractionIndex;
	}
	
	private int fromPairToNodeIndex(int pairIndex) {
		return this.abstractions.length + pairIndex;
	}
	
	private int getNodeIndex(Term term) {
		if (term.isAbstraction())
			return this.fromAbstractionToNodeIndex(this.getAbstractionIndex((Abstraction) term));
		if (term.isPair())
			return this.fromPairToNodeIndex(this.getPairIndex((Pair) term));
		throw new UnexpectedTermException();
	}
	
	private String getTermId(Term term) {
		if (term.isAbstraction()) {
			int abstractionIndex = this.getAbstractionIndex((Abstraction) term);
			return "A" + String.valueOf(abstractionIndex);
		}
		if (term.isLeaf()) {
			int leafIndex = this.getLeafIndex((Leaf) term);
			return "L" + String.valueOf(leafIndex);
		}
		if (term.isPair()) {
			int pairIndex = this.getPairIndex((Pair) term);
			return "P" + String.valueOf(pairIndex);
		}
		throw new UnexpectedTermException();
	}

	private String getNodeId(int nodeIndex) {
		return "N" + String.valueOf(nodeIndex);
	}
	
	private Type getLeafType(Leaf leaf) {
		Abstraction target = leaf.getTarget();
		if (target == null)
			throw new NotInNormalFormException();
		int abstractionIndex = this.getAbstractionIndex(target);
		return this.nodeTypes[this.fromAbstractionToNodeIndex(abstractionIndex)];
	}
	
	private Type getTermType(Term term) {
		if (term.isLeaf())
			return this.getLeafType((Leaf) term);
		int nodeIndex = this.getNodeIndex(term);
		return this.nodeTypes[nodeIndex];
	}
	
	private boolean setTermType(Term term, FunctionType functionType) {
		if (term.isLeaf()) {
			Leaf leaf = (Leaf) term;
			Abstraction target = leaf.getTarget();
			if (target == null)
				throw new NotInNormalFormException();
			return this.setTermType(target, functionType);
		}
		
		int nodeIndex = this.getNodeIndex(term);
		
		if (functionType.length() <= this.nodeTypes[nodeIndex].length())
			return false;
		
		this.nodeTypes[nodeIndex] = functionType;
		this.updatedNodeTypes[nodeIndex] = true;
		
		if (this.reasoning != null)
			this.reasoning.println(this.getNodeId(nodeIndex) + " : " + functionType.toString(this.isCompact));
		
		return true;
	}
	
	@Override
	public Abstraction getHand() {
		return this.abstractions[0];
	}
	
	@Override
	public int getAbstractionCount() {
		return this.abstractions.length;
	}
	
	@Override
	public int getNodeCount() {
		return this.nodeCount;
	}
	
	@Override
	public Term getNode(int nodeIndex) {
		return (nodeIndex < this.abstractions.length) ?
				(Term) this.abstractions[nodeIndex] :
				(Term) this.pairs[nodeIndex - this.abstractions.length];
	}

	@Override
	public Type getNodeType(int nodeIndex) {
		return this.nodeTypes[nodeIndex];
	}
	
	@Override
	public FunctionType evaluatePairFunctionType(Pair pair) {
		Term argument = pair.getRight();
		Type argumentType = this.getTermType(argument);
		Type pairType = this.getTermType(pair);
		FunctionType newFunctionType = this.functionBase.functionType(argumentType, pairType);
		
		if (this.reasoning != null) {
			String argumentId = this.getTermId(argument);
			String pairId = this.getTermId(pair);
			this.reasoning.println(argumentId + " : " + argumentType.toString(this.isCompact));
			this.reasoning.println(this.getTermId(pair) + " : " + pairType.toString(this.isCompact));
			this.reasoning.println("=> (" + argumentId + " -> " + pairId + ") : "
					+ newFunctionType.toString(this.isCompact));
		}
		
		return newFunctionType;
	}

	@Override
	public boolean applyApplicationRules()
			throws NotInNormalFormException, UntypedTermException{
		
		Arrays.fill(this.newNodeTypes, null);
		for (int k = 0; k < this.nodeCount; k++) {
			this.lastUpdatedNodeTypes[k] = this.updatedNodeTypes[k];
			this.updatedNodeTypes[k] = false;
		}
		
		for (int pairIndex = 0; pairIndex < this.pairs.length; pairIndex++) {
			Pair pair = this.pairs[pairIndex];
			int nodeIndex = this.fromPairToNodeIndex(pairIndex);
			this.newNodeTypes[nodeIndex] = this.evaluatePairFunctionType(pair);
		}
		
		for (int pairIndex = 0; pairIndex < this.pairs.length; pairIndex++) {
			Pair pair = this.pairs[pairIndex];
			Term function = pair.getLeft();

			int nodeIndex = this.fromPairToNodeIndex(pairIndex);
			FunctionType newNodeType = this.newNodeTypes[nodeIndex];
			this.updatedNodeTypes[nodeIndex] = this.setTermType(function, newNodeType);
		}
		
		int updatedNodeTypeCount = 0;
		boolean globalPersistence = true;
		
		for (int nodeIndex = 0; nodeIndex < this.nodeCount; nodeIndex++) {
			boolean isUpdated = this.updatedNodeTypes[nodeIndex];
			boolean isLastUpdated = this.lastUpdatedNodeTypes[nodeIndex];
			
			if (isUpdated)
				updatedNodeTypeCount++;

			boolean persistence = (isUpdated == isLastUpdated);
			if (!persistence)
				globalPersistence = false;
		}

		Arrays.fill(this.newNodeTypes, null);
		
		if (updatedNodeTypeCount == 0)
			return true;
		
		if (globalPersistence)
			throw new UntypedTermException();
		
		return false;
	}
	
	@Override
	public boolean isNodeTypeUpdated(int nodeIndex) {
		return this.updatedNodeTypes[nodeIndex];
	}

	@Override
	public FunctionType applyAbstractionRules() {
		
		Type type = this.baseType;

		if (this.pairs.length > 0)
			type = this.getTermType(this.abstractions[this.abstractions.length - 1].getBody());
		
		if (this.reasoning != null) {
			this.reasoning.println("abstraction rules");
			this.reasoning.println("B : " + type.toString(this.isCompact));
		}

		int absCount = this.abstractions.length;
		for (int absIndex = absCount - 1; absIndex >= 0; absIndex--) {
			int nodeIndex = this.fromAbstractionToNodeIndex(absIndex);
			Type nodeType = this.nodeTypes[nodeIndex];
			FunctionType functionType = this.functionBase.functionType(nodeType, type);
			type = functionType;
			
			String rule = "(N" + String.valueOf(nodeIndex) + " -> B) : ["
						+ functionType.getFrom().toString(this.isCompact) + "] -> ["
						+ functionType.getTo().toString(this.isCompact) + "]";
			
			if (this.reasoning != null)
				this.reasoning.println(rule);
			
			if (TRACE)
				System.out.println(rule);
		}
		return (FunctionType) type;
	}
}
