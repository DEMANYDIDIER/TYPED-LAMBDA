package typedLambda.impl.util;

import typedLambda.impl.substitute.SubstitutionImpl;
import typedLambda.impl.term.TermImpl;
import typedLambda.model.substitute.BodySubstitution;
import typedLambda.model.substitute.PairSubstitution;
import typedLambda.model.substitute.Substitution;
import typedLambda.model.substitute.SubstitutionFactory;
import typedLambda.model.term.Abstraction;
import typedLambda.model.term.Leaf;
import typedLambda.model.term.Pair;
import typedLambda.model.term.Term;
import typedLambda.model.term.TermFactory;
import typedLambda.model.term.exception.NotAFreeTermException;
import typedLambda.model.term.exception.UnexpectedTermException;
import typedLambda.model.util.Collector;

public class CollectorImpl implements Collector {

	private final TermFactory<Abstraction> abstractionFactory;
	private final TermFactory<Pair> pairFactory;
	private final TermFactory<Leaf> leafFactory;

	private final SubstitutionFactory<BodySubstitution> abstractionSubstitutionFactory;
	private final SubstitutionFactory<PairSubstitution> leftSubstitutionFactory;
	private final SubstitutionFactory<PairSubstitution> rightSubstitutionFactory;

	public CollectorImpl() {
		
		this.abstractionFactory = TermImpl.termFactories.getAbstractionFactory();
		this.pairFactory = TermImpl.termFactories.getPairFactory();
		this.leafFactory = TermImpl.termFactories.getLeafFactory();

		this.abstractionSubstitutionFactory = SubstitutionImpl.substitutionFactories.getBodySubstitutionFactory();
		this.leftSubstitutionFactory = SubstitutionImpl.substitutionFactories.getLeftSubstitutionFactory();
		this.rightSubstitutionFactory = SubstitutionImpl.substitutionFactories.getRightSubstitutionFactory();
	}

	@Override
	public final Leaf leftmostLeaf(Term container) {
		Term term = container;
		
		while (! term.isLeaf()) {
			
			if (term.isAbstraction()) {
				Abstraction abstraction = (Abstraction) term;
				term = abstraction.getBody();
				
			} else if (term.isPair()) {
				Pair pair = (Pair) term;
				term = pair.getLeft();
				
			} else
				throw new UnexpectedTermException();
		}
		return (Leaf) term;
	}
	
	@Override
	public final Leaf rightmostLeaf(Term container) {
		Term term = container;
		
		while (! term.isLeaf()) {
			
			if (term.isAbstraction()) {
				Abstraction abstraction = (Abstraction) term;
				term = abstraction.getBody();
				
			} else if (term.isPair()) {
				Pair pair = (Pair) term;
				term = pair.getRight();
				
			} else
				throw new UnexpectedTermException();
		}
		return (Leaf) term;
	}
	
	@Override
	public final void returnTermToFactory(Term term) {
		if (term == null)
			throw new IllegalArgumentException();
		if (term.getParent() != null)
			throw new NotAFreeTermException();

		if (term.isLeaf())
			this.leafFactory.returnTerm((Leaf) term);
		else if (term.isAbstraction())
			this.abstractionFactory.returnTerm((Abstraction) term);
		else if (term.isPair())
			this.pairFactory.returnTerm((Pair) term);
		else
			throw new UnexpectedTermException();
	}
	
	@Override
	public final void returnArgumentToFactory(Term argument) {
		if (argument == null)
			throw new IllegalArgumentException();
		if (argument.getParent() != null)
			throw new NotAFreeTermException();
		
		Term term = this.leftmostLeaf(argument);

		while (true) {
			Term parent = term.getParent();
			
			if (parent == null) {
				this.returnTermToFactory(term);
				break;
			}
			if (parent.isAbstraction()) {
				((Abstraction) parent).clearBody();
				this.returnTermToFactory(term);
				term = parent;

			} else if (parent.isPair()) {
				Pair parentPair = (Pair) parent;
				if (term == parentPair.getLeft()) {
					parentPair.clearLeft();
					this.returnTermToFactory(term);
					term = this.leftmostLeaf(parentPair.getRight());
				} else {
					parentPair.clearRight();
					this.returnTermToFactory(term);
					term = parent;
				}
			} else
				throw new UnexpectedTermException();
		}
	}
	
	@Override
	public void returnSubstitutionToFactory(Substitution substitution) {
		if (substitution.isBodySubstitution())
			this.abstractionSubstitutionFactory.returnSubstitution(
					(BodySubstitution) substitution);
		else if (substitution.isLeftSubstitution())
			this.leftSubstitutionFactory.returnSubstitution(
					(PairSubstitution) substitution);
		else if (substitution.isRightSubstitution())
			this.rightSubstitutionFactory.returnSubstitution(
					(PairSubstitution) substitution);
		else
			throw new IllegalStateException();
	}
	
	@Override
	public final void returnSubstitutionListToFactory(
			Substitution substitutionList) {
		if (substitutionList == null || !substitutionList.isNull())
			throw new IllegalArgumentException();
			
		Substitution substitution = substitutionList.getPrevious();
		
		while (! substitution.isNull()) {
			Substitution previous = substitution.getPrevious();
			
			substitution.clear();
			this.returnSubstitutionToFactory(substitution);
			
			substitution = previous;
		}
		substitutionList.setPrevious(substitutionList);
	}
}
