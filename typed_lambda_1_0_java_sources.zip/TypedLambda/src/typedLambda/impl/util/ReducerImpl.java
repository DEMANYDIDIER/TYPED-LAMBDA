package typedLambda.impl.util;

import typedLambda.impl.substitute.BodySubstitutionImpl;
import typedLambda.impl.substitute.LeftSubstitutionImpl;
import typedLambda.impl.substitute.SubstitutionImpl;
import typedLambda.impl.substitute.RightSubstitutionImpl;
import typedLambda.impl.term.AbstractionImpl;
import typedLambda.impl.term.TermImpl;
import typedLambda.model.substitute.BodySubstitution;
import typedLambda.model.substitute.PairSubstitution;
import typedLambda.model.substitute.Substitution;
import typedLambda.model.substitute.SubstitutionFactory;
import typedLambda.model.term.Abstraction;
import typedLambda.model.term.Leaf;
import typedLambda.model.term.Pair;
import typedLambda.model.term.Term;
import typedLambda.model.term.TermFactory;
import typedLambda.model.term.exception.UnexpectedTermException;
import typedLambda.model.util.Collector;
import typedLambda.model.util.Normalization;
import typedLambda.model.util.Reducer;
import typedLambda.model.util.exception.reduce.CopyNotFoundException;
import typedLambda.model.util.exception.reduce.TooMuchBetaReductionException;

public class ReducerImpl implements Reducer {
	public static boolean TRACE = false;

	@SuppressWarnings("unused")
	private static final String termPosition(Term term) {
		StringBuffer sb = new StringBuffer();
		while (true) {
			Term parent = term.getParent();
			if (parent == null)
				break;
			String relation;
			if (parent.isAbstraction())
				relation = "A";
			else if (parent.isPair()) {
				Pair pair = (Pair) parent;
				if (term == pair.getLeft())
					relation = "0";
				else if (term == pair.getRight())
					relation = "1";
				else
					throw new IllegalStateException();
			} else
				throw new UnexpectedTermException();
			sb.insert(0, relation);
			term = parent;
		}
		sb.insert(0, "\"");
		sb.append("\"");
		return sb.toString();
	}

	private static final Term getCopy(Term containerTerm, Term containerCopy, final Term arg)
			throws CopyNotFoundException {

		while (true) {
			/*
			 * containerCopy is clone of containerTerm. arg belons to containerTerm. returns
			 * a clone of arg.
			 */
			if (arg == containerTerm)
				return containerCopy;

			Term term = arg;

			while (true) {
				/*
				 * term belongs to containerTerm.
				 */
				Term parent = term.getParent();

				if (parent == null)
					throw new CopyNotFoundException();

				if (parent == containerTerm)
					break;

				term = parent;
			}
			/*
			 * term is child of containerTerm.
			 */

			if (containerTerm.isAbstraction()) {
				Abstraction termAbstraction = (Abstraction) containerTerm;
				Abstraction copyAbstraction = (Abstraction) containerCopy;

				containerTerm = termAbstraction.getBody();
				containerCopy = copyAbstraction.getBody();

			} else if (containerTerm.isPair()) {
				Pair termPair = (Pair) containerTerm;
				Pair copyPair = (Pair) containerCopy;

				if (term == termPair.getLeft()) {
					containerTerm = termPair.getLeft();
					containerCopy = copyPair.getLeft();

				} else if (term == termPair.getRight()) {
					containerTerm = termPair.getRight();
					containerCopy = copyPair.getRight();
				} else
					throw new IllegalStateException();
			} else
				throw new UnexpectedTermException();
		}
	}

	private static final int substitutionCount(Substitution substitutionList) {
		if (!substitutionList.isNull())
			throw new IllegalArgumentException();

		Substitution substitution = substitutionList.getPrevious(); // top of stack

		int count = 0;

		while (!substitution.isNull()) {
			count++;
			substitution = substitution.getPrevious();
		}
		return count;
	}

	private static final void decrementFreeDBIndexes(Term container) {
		if (container == null)
			throw new IllegalArgumentException();
	
		Term term = container;
		Term backFrom = null;
	
		while (term != null) {
	
			if (term.isLeaf()) {
				Leaf leaf = (Leaf) term;
				leaf.decrementDBIndexIfFree();
				backFrom = term;
				term = term.getParent();
	
			} else if (term.isAbstraction()) {
				if (backFrom == null) {
					Abstraction abstraction = (Abstraction) term;
					term = abstraction.getBody();
					;
				} else {
					backFrom = term;
					term = term.getParent();
				}
	
			} else if (term.isPair()) {
				Pair pair = (Pair) term;
				if (backFrom == null) {
					term = pair.getLeft();
				} else {
					if (backFrom == pair.getLeft()) {
						Term right = pair.getRight();
						term = right;
						backFrom = null;
					} else if (backFrom == pair.getRight()) {
						backFrom = term;
						term = term.getParent();
					} else
						throw new IllegalStateException();
				}
			} else
				throw new UnexpectedTermException();
		}
	}

	private static final void incrementFreeDBIndexes(
			Term container, int count) {
		if (container == null)
			throw new IllegalArgumentException();
	
		Term term = container;
		Term backFrom = null;
	
		while (term != null) {
	
			if (term.isLeaf()) {
				Leaf leaf = (Leaf) term;
				leaf.incrementDBIndexIfFree(count);
				backFrom = term;
				term = term.getParent();
	
			} else if (term.isAbstraction()) {
				if (backFrom == null) {
					Abstraction abstraction = (Abstraction) term;
					term = abstraction.getBody();
					;
				} else {
					backFrom = term;
					term = term.getParent();
				}
	
			} else if (term.isPair()) {
				Pair pair = (Pair) term;
				if (backFrom == null) {
					term = pair.getLeft();
				} else {
					if (backFrom == pair.getLeft()) {
						Term right = pair.getRight();
						term = right;
						backFrom = null;
					} else if (backFrom == pair.getRight()) {
						backFrom = term;
						term = term.getParent();
					} else
						throw new IllegalStateException();
				}
			} else
				throw new UnexpectedTermException();
		}
	}

	private static final void forAllSubstituteByNull(Substitution substitutionList) {
		if (!substitutionList.isNull())
			throw new IllegalArgumentException();
	
		Substitution substitution = substitutionList.getPrevious(); // top of stack
	
		while (!substitution.isNull()) {
			substitution.substituteBy(null);
			substitution = substitution.getPrevious();
		}
	}

	private final Collector collector;
	private final long maxBetaReduction;
	
	private final TermFactory<Abstraction> abstractionFactory;
	private final TermFactory<Pair> pairFactory;
	private final TermFactory<Leaf> leafFactory;

	private final SubstitutionFactory<BodySubstitution> abstractionSubstitutionFactory;
	private final SubstitutionFactory<PairSubstitution> leftSubstitutionFactory;
	private final SubstitutionFactory<PairSubstitution> rightSubstitutionFactory;

	private final Substitution substitutionList = new SubstitutionImpl();
	private final Abstraction capsule = new AbstractionImpl();
	private final Normalization normalization = new Normalization();

	private final BodySubstitution abstractionRedexSubstitution = new BodySubstitutionImpl();
	private final PairSubstitution leftRedexSubstitution = new LeftSubstitutionImpl();
	private final PairSubstitution rightRedexSubstitution = new RightSubstitutionImpl();

	private final BodySubstitution abstractionGoingUpSubstitution = new BodySubstitutionImpl();
	private final PairSubstitution leftGoingUpSubstitution = new LeftSubstitutionImpl();
	private final PairSubstitution rightGoingUpSubstitution = new RightSubstitutionImpl();

	public ReducerImpl(Collector collector, long maxBetaReduction) {
		this.collector = collector;
		this.maxBetaReduction = maxBetaReduction;
		
		this.abstractionFactory = TermImpl.termFactories.getAbstractionFactory();
		this.pairFactory = TermImpl.termFactories.getPairFactory();
		this.leafFactory = TermImpl.termFactories.getLeafFactory();

		this.abstractionSubstitutionFactory = SubstitutionImpl.substitutionFactories.getBodySubstitutionFactory();
		this.leftSubstitutionFactory = SubstitutionImpl.substitutionFactories.getLeftSubstitutionFactory();
		this.rightSubstitutionFactory = SubstitutionImpl.substitutionFactories.getRightSubstitutionFactory();

		this.substitutionList.setPrevious(this.substitutionList);
	}

	private final void storeSubstitutionList(Term container, Abstraction target) {
	
		if (container == null || target == null)
			throw new IllegalArgumentException();
		if (!substitutionList.isNull())
			throw new IllegalArgumentException();
	
		this.substitutionList.setPrevious(this.substitutionList);
	
		Term term = container;
		Term backFrom = null;
	
		while (term != null) {
	
			if (term.isLeaf()) {
				backFrom = term;
				term = term.getParent();
	
			} else if (term.isAbstraction()) {
				if (backFrom == null) {
					Abstraction abstraction = (Abstraction) term;
					Term body = abstraction.getBody();
					if (body.isLeaf()) {
						Leaf leaf = (Leaf) body;
						if (leaf.getTarget() == target) {
							BodySubstitution substitution = this.abstractionSubstitutionFactory.newSubstitution();
							substitution.setAbstraction(abstraction);
							Substitution top = this.substitutionList.getPrevious(); // old top of stack
							substitution.setPrevious(top);
							this.substitutionList.setPrevious(substitution); // new top of stack
						}
					}
					term = body;
				} else {
					backFrom = term;
					term = term.getParent();
				}
	
			} else if (term.isPair()) {
				Pair pair = (Pair) term;
				if (backFrom == null) {
					Term left = pair.getLeft();
					Term right = pair.getRight();
					if (left.isLeaf()) {
						Leaf leaf = (Leaf) left;
						if (leaf.getTarget() == target) {
							PairSubstitution substitution = this.leftSubstitutionFactory.newSubstitution();
							substitution.setPair(pair);
							Substitution top = this.substitutionList.getPrevious(); // old top of stack
							substitution.setPrevious(top);
							this.substitutionList.setPrevious(substitution); // new top of stack
						}
					}
					if (right.isLeaf()) {
						Leaf leaf = (Leaf) right;
						if (leaf.getTarget() == target) {
							PairSubstitution substitution = this.rightSubstitutionFactory.newSubstitution();
							substitution.setPair(pair);
							Substitution top = this.substitutionList.getPrevious(); // old top of stack
							substitution.setPrevious(top);
							this.substitutionList.setPrevious(substitution); // new top of stack
						}
					}
					term = left;
				} else {
					if (backFrom == pair.getLeft()) {
						term = pair.getRight();
						backFrom = null;
					} else if (backFrom == pair.getRight()) {
						backFrom = term;
						term = term.getParent();
					} else
						throw new IllegalStateException();
				}
			} else
				throw new UnexpectedTermException();
		}
	}

	private final void forAllSubstituteByArgument(Substitution substitutionList, Term argumentModel) {
		if (!substitutionList.isNull())
			throw new IllegalArgumentException();
		if (argumentModel == null)
			throw new IllegalArgumentException();
	
		Substitution substitution = substitutionList.getPrevious(); // top of stack
		int n = substitutionCount(this.substitutionList);
		
		while (!substitution.isNull()) {
			int bindersCount = substitution.bindersCount();
			Term argument = (n > 1) ? cloneTerm(argumentModel) : argumentModel;
			if (bindersCount > 0)
				incrementFreeDBIndexes(argument, bindersCount);
			substitution.substituteBy(argument);
			substitution = substitution.getPrevious();
			n--;
		}
		if (n != 0)
			throw new IllegalStateException();
	}

	private final Substitution redexSubstitution(Term target) {
		Term parent = target.getParent();
		if (parent == null)
			return null;
		
		if (parent.isAbstraction()) {
			this.abstractionRedexSubstitution.setAbstraction((Abstraction) parent);
			return this.abstractionRedexSubstitution;
		}
		if (parent.isPair()) {
			Pair parentPair = (Pair) parent;
			if (target == parentPair.getLeft()) {
				this.leftRedexSubstitution.setPair(parentPair);
				return this.leftRedexSubstitution;
			} else if (target == parentPair.getRight()) {
				this.rightRedexSubstitution.setPair(parentPair);
				return this.rightRedexSubstitution;
			} else
				throw new IllegalStateException();
		}
		throw new UnexpectedTermException();
	}

	private final Substitution goingUpSubstitution(Term target) {
		Term parent = target.getParent();
		if (parent == null)
			return null;
		
		if (parent.isAbstraction()) {
			this.abstractionGoingUpSubstitution.setAbstraction((Abstraction) parent);
			return this.abstractionGoingUpSubstitution;
		}
		if (parent.isPair()) {
			Pair parentPair = (Pair) parent;
			if (target == parentPair.getLeft()) {
				this.leftGoingUpSubstitution.setPair(parentPair);
				return this.leftGoingUpSubstitution;
			} else if (target == parentPair.getRight()) {
				this.rightGoingUpSubstitution.setPair(parentPair);
				return this.rightGoingUpSubstitution;
			} else
				throw new IllegalStateException();
		}
		throw new UnexpectedTermException();
	}

	/*
	 * xλy.M -> λy.xM
	 */
	private final int abstractionGoesUp(Pair lastPair) {
		if (lastPair == null)
			throw new IllegalArgumentException();
		
		if (!lastPair.getRight().isAbstraction())
			return 0;
		
		Pair firstPair = lastPair;
		int pairCount = 1;
		
		while (firstPair.getParent().isPair()
				&& ((Pair) firstPair.getParent()).getLeft().isLeaf()) {
			firstPair =  (Pair) firstPair.getParent();
			pairCount++;
		}
		
		Abstraction firstAbstraction = (Abstraction) lastPair.getRight();
		Abstraction lastAbstraction = firstAbstraction;
		int bindersCount = 1;
		
		while (lastAbstraction.getBody().isAbstraction()) {
			lastAbstraction = (Abstraction) lastAbstraction.getBody();
			bindersCount++;
		}
		
		Substitution substitution = this.goingUpSubstitution(firstPair);
		Term nextTerm = lastAbstraction.getBody();
		
		substitution.substituteBy(null);
		lastPair.clearRight();
		lastAbstraction.clearBody();
		
		Pair pair = lastPair;
		for (int k = 0; k < pairCount; k++) {
			Term term = pair.getLeft();
			incrementFreeDBIndexes(term, bindersCount);
			if (pair != firstPair)
				 pair = (Pair) pair.getParent();
		}
		
		substitution.substituteBy(firstAbstraction);
		substitution.clear();
		lastAbstraction.setBody(firstPair);
		lastPair.setRight(nextTerm);
		
		return  pairCount * bindersCount;
	}

	@SuppressWarnings("unchecked")
	@Override
	public final <T extends Term> T cloneTerm(T container) {
		if (container == null)
			throw new IllegalArgumentException();

		/*
		 * Build left chain.
		 */
		Leaf termLeaf = this.collector.leftmostLeaf(container);
		Leaf copyLeaf = (Leaf) this.leafFactory.newTerm();
		{
			int dBIndex = termLeaf.getDBIndex();
			copyLeaf.setDBIndex(dBIndex);

//			if (TRACE)
//				System.out.println(termPosition(termLeaf) + " A" + String.valueOf(dBIndex));
		}

		Term term = termLeaf;
		Term copy = copyLeaf;

		while (true) {
			Term termParent = term.getParent();
			Term copyParent = null;

			if (termParent == null)
				break;

			if (termParent.isAbstraction()) {
				Abstraction abstraction = this.abstractionFactory.newTerm();
				abstraction.setBody(copy);
				copyParent = abstraction;

			} else if (termParent.isPair()) {
				Pair pair = this.pairFactory.newTerm();
				pair.setLeft(copy);
				copyParent = pair;

			} else
				throw new UnexpectedTermException();

//			if (TRACE)
//				System.out.println(termPosition(termParent) + " B " + termParent.toString());

			term = termParent;
			copy = copyParent;
		}
		Term containerTerm = term;
		Term containerCopy = copy;

		if (containerTerm != container)
			throw new IllegalStateException();

		while (true) {

			/*
			 * Leftmost parent.
			 */
			term = termLeaf;

			while (true) {
				Term termParent = term.getParent();

				if (termParent == null)
					break;

				if (termParent.isPair() && term == ((Pair) termParent).getLeft())
					break;

				term = termParent;
			}

			/*
			 * Up and right.
			 */
			term = term.getParent();

			if (term == null)
				break;

			term = ((Pair) term).getRight();

			/*
			 * Leftmost leaf
			 */
			termLeaf = this.collector.leftmostLeaf(term);

			/*
			 * Next leaf.
			 */
			copyLeaf = this.leafFactory.newTerm();
			{
				int dBIndex = termLeaf.getDBIndex();
				copyLeaf.setDBIndex(dBIndex);

//				if (TRACE)
//					System.out.println(termPosition(termLeaf) + " C" + String.valueOf(dBIndex));
			}

			/*
			 * Build left chain
			 */
			term = termLeaf;
			copy = copyLeaf;

			while (true) {
				Term termParent = term.getParent();
				Term copyParent = null;

				if (termParent == null)
					break;

				if (termParent.isAbstraction()) {
					Abstraction abstraction = this.abstractionFactory.newTerm();
					abstraction.setBody(copy);
					copyParent = abstraction;

				} else if (termParent.isPair()) {
					Pair termParentPair = (Pair) termParent;
					if (term == termParentPair.getLeft()) {
						Pair pair = this.pairFactory.newTerm();
						pair.setLeft(copy);
						copyParent = pair;

					} else if (term == termParentPair.getRight())
						break;
					else
						throw new IllegalStateException();
				} else
					throw new UnexpectedTermException();

//				if (TRACE)
//					System.out.println(termPosition(termParent) + " D " + termParent.toString() + " " + copyParent.toString());

				term = termParent;
				copy = copyParent;
			}

			Term parentTerm = term.getParent();
			Term parentCopy = getCopy(containerTerm, containerCopy, parentTerm);

			((Pair) parentCopy).setRight(copy);
		}

		/*
		 * Existence of the rightest leaf.
		 */
		this.collector.rightmostLeaf(containerCopy);

		return (T) containerCopy;
	}

	@Override
	public final Pair leftmostRedex(Term container, boolean trueRedex) {
		if (container == null)
			throw new IllegalArgumentException();

		Term term = container;
		Term backFrom = null;

		while (term != null) {

			if (term.isLeaf()) {
				backFrom = term;
				term = term.getParent();

			} else if (term.isAbstraction()) {
				if (backFrom == null) {
					Abstraction abstraction = (Abstraction) term;
					term = abstraction.getBody();
					;
				} else {
					backFrom = term;
					term = term.getParent();
				}

			} else if (term.isPair()) {
				Pair pair = (Pair) term;
				if (backFrom == null) {
					if ((trueRedex ? pair.getLeft() : pair.getRight())
							.isAbstraction())
						return pair;
					term = pair.getLeft();
				} else {
					if (backFrom == pair.getLeft()) {
						term = pair.getRight();
						backFrom = null;
					} else if (backFrom == pair.getRight()) {
						backFrom = term;
						term = term.getParent();
					} else
						throw new IllegalStateException();
				}
			} else
				throw new UnexpectedTermException();
		}
		return null;
	}

	@Override
	public final int reduceRedex(Abstraction container, Pair redex) {
		if (container == null || redex == null || !redex.getLeft().isAbstraction())
			throw new IllegalArgumentException();

//		if (TRACE)
//			System.out.println("reduceRedex " + redex.toDeBruijnString());

		Substitution redexSubstitution = this.redexSubstitution(redex);

		Abstraction target = (Abstraction) redex.getLeft();
		Term argumentModel = redex.getRight();
		Term body = target.getBody();

		this.substitutionList.setPrevious(this.substitutionList);
		this.storeSubstitutionList(body, target);
		int substitutionCount = substitutionCount(this.substitutionList);

//		if (TRACE)
//			System.out.println("Substitutioncount : " + String.valueOf(substitutionCount));

		redex.clear();
		target.clearBody();

		forAllSubstituteByNull(this.substitutionList);

		decrementFreeDBIndexes(body);

		if (substitutionCount > 0) {
			forAllSubstituteByArgument(this.substitutionList, argumentModel);
			argumentModel = null;
		}
		
		redexSubstitution.substituteBy(null);
		redexSubstitution.substituteBy(body);
		redexSubstitution.clear();

		this.collector.returnSubstitutionListToFactory(this.substitutionList);
		
		if (argumentModel != null)
			this.collector.returnArgumentToFactory(argumentModel);
		
		this.pairFactory.returnTerm(redex);
		this.abstractionFactory.returnTerm(target);

		return substitutionCount;
	}

	@Override
	public final Term reduceRedex(Pair redex) {
		if (redex == null || !redex.getLeft().isAbstraction())
			throw new IllegalArgumentException();
		if (!this.capsule.isCleared() || this.capsule.getParent() != null)
			throw new IllegalStateException();

		this.capsule.setBody(redex);

		this.reduceRedex(this.capsule, redex);
		Term result = this.capsule.getBody();

		this.capsule.clear();
		return result;
	}

	@Override
	public final Normalization normalize(Abstraction container)
			throws TooMuchBetaReductionException {
		if (container == null)
			throw new IllegalArgumentException();

		long reductionCount = 0;
		long substitutionCount = 0;
		int goingUpCount = 0;

		boolean noRedex = false;
		boolean noGoingUp = false;
		
		while (true) {

			while (true) {
				Pair redex = this.leftmostRedex(container, true);
				noRedex = (redex == null);
				
				if (noRedex)
					break;
				
				substitutionCount += this.reduceRedex(container, redex);
				reductionCount++;
				noGoingUp = false;
				
				if (reductionCount > this.maxBetaReduction)
					throw new TooMuchBetaReductionException();
			}
			if (noRedex && noGoingUp)
				break;
			
			while (true) {
				Pair goingUp = this.leftmostRedex(container, false);
				noGoingUp = (goingUp == null);
				
				if (noGoingUp)
					break;
				
				goingUpCount += this.abstractionGoesUp(goingUp);
				noRedex = false;
			}
			if (noRedex && noGoingUp)
				break;
		}
		
		this.normalization.reductionCount = reductionCount;
		this.normalization.substitutionCount = substitutionCount;
		this.normalization.goingUpCount = goingUpCount;

		return this.normalization;
	}

	@Override
	public final Term normalize(Pair container)
			throws TooMuchBetaReductionException {
		if (container == null)
			throw new IllegalArgumentException();

		if (!this.capsule.isCleared() || this.capsule.getParent() != null)
			throw new IllegalStateException();

		this.capsule.setBody(container);

		this.normalize(this.capsule);

		Term newContainer = this.capsule.getBody();
		this.capsule.clear();

		return newContainer;
	}

	@Override
	public final Normalization lastNormalization() {
		return this.normalization;
	}
}
