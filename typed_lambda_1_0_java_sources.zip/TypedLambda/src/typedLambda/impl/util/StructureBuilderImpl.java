package typedLambda.impl.util;

import typedLambda.impl.term.TermImpl;
import typedLambda.model.term.Abstraction;
import typedLambda.model.term.Leaf;
import typedLambda.model.term.Pair;
import typedLambda.model.term.Term;
import typedLambda.model.term.TermFactory;
import typedLambda.model.term.exception.BrokenArgumentException;
import typedLambda.model.util.StructureBuilder;

public class StructureBuilderImpl implements StructureBuilder {
	private final TermFactory<Abstraction> abstractionFactory;
	private final TermFactory<Pair> pairFactory;
	private final TermFactory<Leaf> leafFactory;

	public StructureBuilderImpl() {
		this.abstractionFactory = TermImpl.termFactories.getAbstractionFactory();
		this.pairFactory = TermImpl.termFactories.getPairFactory();
		this.leafFactory = TermImpl.termFactories.getLeafFactory();
	}
	
	@Override
	public Abstraction newIdentity() {
		Abstraction abstraction = this.abstractionFactory.newTerm();
		Leaf leaf = this.leafFactory.newTerm();
		leaf.setDBIndex(1);
		abstraction.setBody(leaf);
		return abstraction;
	}
	
	@Override
	public Abstraction newBoolean(boolean value) {
		Abstraction abstractionX = this.abstractionFactory.newTerm();
		Abstraction abstractionY = this.abstractionFactory.newTerm();
		Leaf leaf = this.leafFactory.newTerm();
		leaf.setDBIndex(value ? 2 : 1);
		abstractionY.setBody(leaf);
		abstractionX.setBody(abstractionY);
		return abstractionX;
	}
	
	@Override
	public final Abstraction newNumeral(int n) {
		
		Leaf leaf_x = this.leafFactory.newTerm();
		leaf_x.setDBIndex(1);
		Term term = leaf_x;
		
		while (n-- > 0) {
			
			Leaf leaf_f = this.leafFactory.newTerm();
			leaf_f.setDBIndex(2);
			
			Pair pair = this.pairFactory.newTerm();
			pair.setLeft(leaf_f);
			pair.setRight(term);
			term = pair;
		}
		
		Abstraction abstraction_x = this.abstractionFactory.newTerm();
		abstraction_x.setBody(term);
		
		Abstraction abstraction_f = this.abstractionFactory.newTerm();
		abstraction_f.setBody(abstraction_x);
		
		return abstraction_f;
	}

	@Override
	public Abstraction newCouple(Term component1, Term component2) {
		if (component1 == null || component2 == null)
			throw new IllegalArgumentException();
		if (component1.isBroken() || component2.isBroken())
			throw new BrokenArgumentException();

		Leaf leaf = this.leafFactory.newTerm();
		leaf.setDBIndex(1);
		
		Pair pair1 = this.pairFactory.newTerm();
		pair1.setLeft(leaf);
		pair1.setRight(component1);
		
		Pair pair2 = this.pairFactory.newTerm();
		pair2.setLeft(pair1);
		pair2.setRight(component2);
		
		Abstraction abstraction = this.abstractionFactory.newTerm();
		abstraction.setBody(pair2);
		return abstraction;
	}
}
