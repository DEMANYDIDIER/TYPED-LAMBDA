package typedLambda;

public class Chrono {
	public long t0 = 0;
	public long t1 = 0;
	
	public Chrono() {
	}
	
	public void setT0() {
		this.t0 = System.currentTimeMillis();
	}
	
	public void setT1() {
		this.t1 = System.currentTimeMillis();
	}
	
	public String elapsed() {
		return String.valueOf(t1 - t0) + " ms";
	}
}
