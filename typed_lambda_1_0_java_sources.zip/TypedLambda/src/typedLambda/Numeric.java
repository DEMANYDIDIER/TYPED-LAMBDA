package typedLambda;

import typedLambda.model.term.Abstraction;
import typedLambda.model.term.Pair;
import typedLambda.model.term.Term;

public abstract class Numeric {
	
	public static final int toInt(Abstraction combinator) {
		int n = 0;
		
		Term term = combinator.getBody();
		if (! term.isAbstraction())
			return 0;
		
		Abstraction abstraction_x = (Abstraction) term;
		term = abstraction_x.getBody();
		
		while (term.isPair()) {
			Pair pair = (Pair) term;
			if (! pair.getLeft().isLeaf())
				return 0;
			term = pair.getRight();
			n++;
		}
		
		return n;
	}

	public static final String toDecimal(Abstraction combinator) {
		return "decimal " + String.valueOf(toInt(combinator));
	}
	
	private static final String toBinary(int n) {
		if (n < 0)
			throw new IllegalArgumentException();
		
		if (n == 0)
			return "0";
		
		StringBuffer sb = new StringBuffer();
		while (n > 0) {
			int bit = n % 2;
			n = n / 2;
			sb.insert(0, bit);
		}
		return sb.toString();
	}
	
	public static final String toBinary(Abstraction combinator) {
		return "binary " + toBinary(toInt(combinator));
	}

	private static final String toHexa(int n) {
		if (n < 0)
			throw new IllegalArgumentException();
		
		if (n == 0)
			return "0";
		
		StringBuffer sb = new StringBuffer();
		while (n > 0) {
			int hexa = n % 16;
			n = n / 16;
			sb.insert(0, "0123456789abcdef".charAt(hexa));
		}
		//sb.insert(0, "0x");
		return sb.toString();
	}

	public static final String toHexa(Abstraction combinator) {
		return "hexa " + toHexa(toInt(combinator));
	}

	public static final String toDecimalAndBinaryAndHexa(Abstraction combinator) {
		int n = toInt(combinator);
		return "decimal " + String.valueOf(n)
			+ " binary " + toBinary(n)
			+ " hexa " + toHexa(n);
	}
}
