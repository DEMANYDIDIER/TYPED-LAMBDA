package typedLambda.common;

import java.io.PrintStream;

public class LambdaException extends RuntimeException {
	private static final long serialVersionUID = 1L;

	public LambdaException() {
	}

	public void printContext(PrintStream out) {}
	
	public void printStackTrace(PrintStream out) {
		super.printStackTrace(out);
	}
}
