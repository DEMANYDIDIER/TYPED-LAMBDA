package typedLambda.common;

public final class Literal {
	public static final Literal I = new Literal("x", "x");
	public static final Literal K = new Literal("xy", "x");
	public static final Literal KI = new Literal("xy", "y");
	public static final Literal ONE = new Literal("fx", "fx");
	public static final Literal TWO = new Literal("fx", "f(fx)");
	public static final Literal TREE = new Literal("fx", "f(f(fx))");
	public static final Literal POWER = new Literal("xy","yx");
	public static final Literal IF_THEN_ELSE = new Literal("xyz", "xyz");
	public static final Literal SUCC = new Literal("nfx", "f(nfx)");
	public static final Literal PAIR = new Literal("xyz", "zxy");
	public static final Literal FIRST = new Literal("pxy", "px");
	public static final Literal SECOND = new Literal("pxy", "py");
	public static final Literal ADD = new Literal("mnfx", "mf(nfx)");
	public static final Literal MULT = new Literal("mnfx","m(nf)x");

	private static final int getIndex(char ch, String s) {
		for (int k = 0; k < s.length(); k++)
			if (ch == s.charAt(k))
				return k;
		return -1;
	}
	
	private static final String translate(String expression, String varChars) {
		StringBuffer sb = new StringBuffer();
		for (int k = 0; k < expression.length(); k++) {
			char ch = expression.charAt(k);
			int index = getIndex(ch, varChars);
			if (index >= 0)
				ch = (char) ('a' +index);
			sb.append(ch);
		}
		return sb.toString();
	}
	
	public final int abstractionCount;
	public final String expression;
	
	private int leafCount = 0;
	
	public Literal(int abstractionCount, String expression) {
		if (abstractionCount < 1 || abstractionCount > 26)
			throw new IllegalArgumentException();
		
		this.abstractionCount = abstractionCount;
		this.expression = expression;
		
		for (int k = 0; k < expression.length(); k++) {
			char ch = expression.charAt(k);
			boolean isParenthesis = (ch == '(') || (ch == ')');
			if (!isParenthesis)
				if ((ch >= 'a') && (ch < (char) ('a' + abstractionCount)))
					this.leafCount++;
				else
					throw new IllegalArgumentException();
		}
		int parentLevel = 0;
		for (int k = 0; k < expression.length(); k++) {
			char ch = expression.charAt(k);
			if (ch == '(')
				parentLevel++;
			else if (ch == ')') {
				parentLevel --;
				if (parentLevel < 0)
					throw new IllegalArgumentException();
			}
		}
		if (parentLevel != 0)
			throw new IllegalArgumentException();
	}

	public Literal(String varChars, String expression) {
		this(varChars.length(), translate(expression, varChars));
	}
	
	public final int getLeafCount() {
		return this.leafCount;
	}
	
	@Override
	public final String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append("λ");
		for (int absIndex = 0; absIndex < this.abstractionCount; absIndex++)
			sb.append(String.valueOf((char)('a' + absIndex)));
		sb.append(".");
		sb.append(this.expression);
		return sb.toString();
	}
}
