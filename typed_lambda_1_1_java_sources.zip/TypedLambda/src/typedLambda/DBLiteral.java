package typedLambda;

public interface DBLiteral {
	public static final String I = "λ 1";
	public static final String K = "λ λ 2";
	public static final String KI = "λ λ 1";
	public static final String ONE = "λ λ 2 1";
	public static final String TWO = "λ λ 2 (2 1)";
	public static final String TREE = "λ λ 2 (2 (2 1))";
	public static final String POWER = "λ λ 1 2";
	public static final String IF_THEN_ELSE = "λ λ λ 3 2 1";
	public static final String SUCC = "λ λ λ 2 (3 2 1)";
	public static final String PAIR = "λ λ λ 1 3 2";
	public static final String FIRST = "λ λ λ 3 2";
	public static final String SECOND = "λ λ λ 3 1";
	public static final String ADD = "λ λ λ λ 4 2 (3 2 1)";
	public static final String MULT = "λ λ λ λ 4 (3 2) 1";
	public static final String WIKI = "(λ λ 4 2 (λ 1 3)) (λ 5 1)";
}
