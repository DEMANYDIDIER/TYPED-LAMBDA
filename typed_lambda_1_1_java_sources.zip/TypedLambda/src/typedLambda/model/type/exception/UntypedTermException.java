package typedLambda.model.type.exception;

import java.io.PrintStream;

import typedLambda.common.LambdaException;
import typedLambda.common.Literal;

/*
 * Exception thrown by a tentative of assigning a Type to an untypable Term.
 */
public final class UntypedTermException extends LambdaException {
	private static final long serialVersionUID = 1L;

	public final Literal termLitteral;
	
	public UntypedTermException() {
		this.termLitteral = null;
	}
	
	public UntypedTermException(Literal termLitteral) {
		this.termLitteral = termLitteral;
	}
	
	@Override
	public void printContext(PrintStream out) {
		if (this.termLitteral != null)
			out.println(this.termLitteral.toString() + " cannot be typed");
	}
}
