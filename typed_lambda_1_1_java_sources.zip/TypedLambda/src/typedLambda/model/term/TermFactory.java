package typedLambda.model.term;

import typedLambda.model.term.exception.LinkedTermException;
import typedLambda.model.term.exception.NotAFreeTermException;

/*
 * A TermFactory recycle's lambda Terms in order to avoiding to making working
 * 	the native Java garbage collector during term beta reduction.
 * 
 * This parameterized interface is declined in the TermFactory<Abstraction>,
 * 	the TermFactory<Leaf> and the TermFactory<Application>.
 */
public interface TermFactory<T extends Term> {

	/*
	 * Provides a new Term.
	 * 
	 * This new Term is either an Abstraction, a Leaf or a Pair,
	 * 	depending on the parameter T of the interface.
	 */
	public T newTerm();

	/*
	 * Returns the given Term to the TermFactory.
	 * 
	 * No reference must be made any more to this Term.
	 * In the contrary case, the implementation behavior becomes unpredictable.
	 * 
	 * The Term must be free, i.e. to have no parent.
	 * The Term must be not linked, i.e. to have no child.
	 */
	public void returnTerm(T term)
			throws NotAFreeTermException, LinkedTermException;
	
	/*
	 * Returns the memory size required for storing the terms
	 * 	that wait before next reusing.
	 * 
	 * The unit is a 32 bits word,
	 * 	i.e. the size of an integer or a reference on a usual desk machine.
	 */
	public int getMemorySize();
}
