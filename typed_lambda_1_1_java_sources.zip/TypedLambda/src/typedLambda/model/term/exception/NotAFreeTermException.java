package typedLambda.model.term.exception;

import typedLambda.common.LambdaException;

/*
 * Exception thrown by a tentative of using a Term already linked.
 */
public final class NotAFreeTermException extends LambdaException {
	private static final long serialVersionUID = 1L;

	public NotAFreeTermException() {
	}
}
