package typedLambda.model.term.exception;

import typedLambda.common.LambdaException;

/*
 * Exception thrown when reciprocity doesn't exist between a Term and its parent.
 */
public final class NoReciprocityException extends LambdaException {
	private static final long serialVersionUID = 1L;

	public NoReciprocityException() {
	}
}
