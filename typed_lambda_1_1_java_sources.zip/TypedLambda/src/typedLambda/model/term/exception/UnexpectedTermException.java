package typedLambda.model.term.exception;

import java.io.PrintStream;

import typedLambda.common.LambdaException;

/*
 * Exception thrown by meeting a Term that is
 * 	neither an Abstraction
 * 	neither a Leaf
 * 	neither a Pair
 */
public class UnexpectedTermException extends LambdaException {
	private static final long serialVersionUID = 1L;

	public UnexpectedTermException() {
	}

	@Override
	public void printContext(PrintStream out) {
	}
}
