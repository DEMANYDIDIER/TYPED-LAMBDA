package typedLambda.model.term.exception;

import typedLambda.common.LambdaException;

/*
 * Exception thrown by a direct tentative to set a new link.
 * Clearing previously the previous link is necessary.
 * 
 * Setting operation may be :
 * 	Abstraction.setBody()
 * 	Pair.setLeft()
 * 	Pair.setRight()
 */
public final class ClearFirstException extends LambdaException {
	private static final long serialVersionUID = 1L;

	public ClearFirstException() {
	}
}
