package typedLambda.model.term.exception;

import java.io.PrintStream;

import typedLambda.common.LambdaException;
import typedLambda.impl.util.ConverterFromTree;
import typedLambda.model.term.Abstraction;

/*
 * Exception thrown when a bind from a Leaf is lost.
 */
public final class AbstractionNotFoundException extends LambdaException {
	private static final long serialVersionUID = 1L;

	public final Abstraction before;
	public final Abstraction after;
	
	public AbstractionNotFoundException(
			Abstraction before, Abstraction after) {
		this.before = before;
		this.after = after;
	}

	public AbstractionNotFoundException() {
		this(null, null);
	}
	
	public void printContext(PrintStream out) {
		if (this.before != null) {
			out.println("before " + this.before.toDetailedDeBruijnString(null));
		}
		if (this.after != null) {
			out.println("after " + this.after.toDetailedDeBruijnString(null));
			try {
				out.println(ConverterFromTree.convertToLiteral(this.after).toString());
			} catch (Exception e) {}
		}
	}
}
