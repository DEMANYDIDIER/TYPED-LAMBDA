package typedLambda.model.term;

import java.util.EmptyStackException;

public interface TermStack {

	public void clear();

	public int size();
	
	public void add(Term term);
	
	public Term get(int k);
	
	public Term top() throws EmptyStackException;
	
	public Term pop() throws EmptyStackException;
}
