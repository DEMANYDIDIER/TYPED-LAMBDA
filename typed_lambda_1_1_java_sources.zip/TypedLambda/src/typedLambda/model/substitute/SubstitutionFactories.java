package typedLambda.model.substitute;

/*
 * Provides an access to the three substitution factories.
 */
public interface SubstitutionFactories {

	/*
	 * Provides an access to the body substitutions factory.
	 */
	public SubstitutionFactory<BodySubstitution> getBodySubstitutionFactory();
	
	/*
	 * Provides an access to the left substitutions factory.
	 */
	public SubstitutionFactory<PairSubstitution> getLeftSubstitutionFactory();

	/*
	 * Provides an access to the right substitutions factory.
	 */
	public SubstitutionFactory<PairSubstitution> getRightSubstitutionFactory();

	/*
	 * Returns the memory size required for storing the substitutions
	 * 	that wait before next reusing.
	 * 
	 * The unit is a 32 bits word,
	 * 	i.e. the size of an integer or a reference on a usual desk machine.
	 */
	public int getMemorySize();
}
