package typedLambda.model.util;

import typedLambda.model.term.Abstraction;
import typedLambda.model.term.Leaf;
import typedLambda.model.term.Term;
import typedLambda.model.util.exception.ReconnectionNotPossibleException;

/*
 * The StructureBuilder proposes the building of various combinators.
 */
public interface StructureBuilder {

	/*
	 * Returns an Identity combinator.
	 * I is the only Term typed by (o -> o).
	 */
	public Abstraction newIdentity();
	
	/*
	 * Returns a boolean combinator that represents the given Boolean values.
	 * 
	 * K and F are the only terms typed by (o -> f).
	 */
	public Abstraction newBoolean(boolean value);
	
	/*
	 * Permutes the Boolean value of the given member of the Boolean family.
	 */
	public void permutBoolean(Abstraction hand);

	/*
	 * Returns a Church numeral combinator with the given value.
	 * 
	 * The natural numbers are typed by (f -> f).
	 * Zero, alias F, belongs to the booleans.
	 */
	public Abstraction newNumeral(int n);

	/*
	 * Returns a new combinator that represents one amongst several.
	 */
	public Abstraction newOneAmongstSeveral(int n);

	/*
	 * Returns a new combinator that represents several amongst several.
	 */
	public Abstraction newSeveralAmongstSeveral(int n, int p);
	
	/*
	 * Reconnects a Leaf of a connection array.
	 * 
	 * The new target must be free.
	 */
	public void reconnect(Abstraction hand, Leaf leaf, Abstraction newTarget)
		throws ReconnectionNotPossibleException;
	
	/*
	 * Returns a pair of terms.
	 * 
	 * Pairs of booleans are typed by (f -> o -> b).
	 * Pairs of natural numbers are typed by (f -> b -> b).
	 */
	public Abstraction newCouple(Term component1, Term component2);
	
	/*
	 * Returns a list of terms.
	 * 
	 * Lists of booleans are typed by (f -> b).
	 * Lists of natural numbers are typed by (f -> n).
	 * Lists of <T> are typed by (f -> <T>).
	 */
	public Abstraction newList(Term[] elements);
	
	/*
	 * Returns the encapsulated application of a function to an argument.
	 */
	public Abstraction newApplication(Abstraction function, Term argument);
}
