package typedLambda.model.util;

import typedLambda.model.substitute.Substitution;
import typedLambda.model.term.Leaf;
import typedLambda.model.term.Term;

/*
 * a Collector collects reusable objects.
 */
public interface Collector {

	/*
	 * Returns the leftmost Leaf in the given Term.
	 */
	public Leaf leftmostLeaf(Term term);
	
	/*
	 * Returns the rightmost Leaf in the given Term.
	 */
	public Leaf rightmostLeaf(Term term);
	
	/*
	 * Returns an unlinked Term to factory.
	 */
	public void returnTermToFactory(Term term);

	/*
	 * Returns an entire argument to factory.
	 */
	public void returnArgumentToFactory(Term argument);

	/*
	 * Returns a Substitution of the given target.
	 */
	public Substitution newSubstitution(Term target);
	
	/*
	 * Returns a Substitution to its factory.
	 */
	public void returnSubstitutionToFactory(Substitution substitution);
	
	/*
	 * Returns the not null substitutions contained in a circular list to the factory.
	 * 
	 * The circular list becomes empty.
	 */
	public void returnSubstitutionListToFactory(Substitution substitutionList);
}
