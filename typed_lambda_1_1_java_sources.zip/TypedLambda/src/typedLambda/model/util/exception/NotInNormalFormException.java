package typedLambda.model.util.exception;

import typedLambda.common.LambdaException;

/*
 * The following operations require a combinator :
 * 	Converting from tree form to literal form
 * 	Type assignment
 */
public final class NotInNormalFormException extends LambdaException {
	private static final long serialVersionUID = 1L;

	public NotInNormalFormException() {
	}
}
