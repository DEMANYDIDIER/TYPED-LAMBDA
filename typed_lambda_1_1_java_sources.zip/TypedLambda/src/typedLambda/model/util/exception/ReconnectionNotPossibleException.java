package typedLambda.model.util.exception;

import typedLambda.common.LambdaException;

/*
 * Exception thrown by a tentative to execute an erroneous reconnection.
 */
public final class ReconnectionNotPossibleException extends LambdaException {
	private static final long serialVersionUID = 1L;

	public ReconnectionNotPossibleException() {
	}
}
