package typedLambda.model.util.exception.convert;

import java.io.PrintStream;

import typedLambda.common.LambdaException;

/*
 * Exception thrown at reading an expression.
 */
public abstract class ReadingExpressionException
		extends LambdaException {
	private static final long serialVersionUID = 1L;

	public final String expression;
	
	public ReadingExpressionException(String expression) {
		this.expression = expression;
	}

	@Override
	public void printContext(PrintStream out) {
		out.println("Exp : \"" + this.expression + "\"");
	}
}
