package typedLambda.model.util.exception.convert;

/*
 * Exception thrown by a premature end of expression.
 */
public final class UncompleteExpressionException
		extends ReadingExpressionException {
	private static final long serialVersionUID = 1L;

	public UncompleteExpressionException(String expression) {
		super(expression);
	}
}
