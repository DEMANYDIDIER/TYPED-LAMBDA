package typedLambda.model.util.exception.convert;

/*
 * Exception thrown by a tentative to close an expression
 * 	without corresponding opening.
 */
public final class TooMutchClosingException extends ReadingExpressionException {
	private static final long serialVersionUID = 1L;

	public TooMutchClosingException(String expression) {
		super(expression);
	}
}
