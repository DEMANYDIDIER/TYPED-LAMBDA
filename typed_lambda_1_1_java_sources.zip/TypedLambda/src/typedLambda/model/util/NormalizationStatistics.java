package typedLambda.model.util;

public final class NormalizationStatistics {
	public int reductionCount = 0;
	public int substitutionCount = 0;
	public int goingUpCount = 0;
	
	
	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append(String.valueOf(this.reductionCount));
		sb.append(" reductions, ");
		sb.append(String.valueOf(this.substitutionCount));
		sb.append(" substitutions");
		if (this.goingUpCount > 0) {
			sb.append(", ");
			sb.append(String.valueOf(this.goingUpCount));
			sb.append(" goingUp.");
		}
		sb.append(".");
		return sb.toString();
	}
}
