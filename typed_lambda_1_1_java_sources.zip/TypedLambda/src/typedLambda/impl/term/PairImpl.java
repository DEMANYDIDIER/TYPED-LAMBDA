package typedLambda.impl.term;

import typedLambda.model.term.Pair;
import typedLambda.model.term.Term;
import typedLambda.model.term.exception.ClearFirstException;
import typedLambda.model.term.exception.NoReciprocityException;
import typedLambda.model.term.exception.NotAFreeTermException;

public final class PairImpl extends TermImpl implements Pair {
	public static final int pairSize = 7;

	TermImpl left = null;
	TermImpl right = null;
	
	public PairImpl() {
	}

	@Override
	public boolean isPair() {
		return true;
	}

	@Override
	public boolean isLeaf() {
		return false;
	}

	@Override
	public boolean isAbstraction() {
		return false;
	}

	@Override
	public Term getLeft() {
		return this.left;
	}

	@Override
	public void setLeft(Term left) {
		if (left == this.left)
			return;
		
		if (left == null) {
			this.clearLeft();
			return;
		}
		
		if (this.reusePort != null)
			throw new IllegalStateException();
		if (this.left != null)
			throw new ClearFirstException();			
		if (left.getParent() != null)
			throw new NotAFreeTermException();
		
		/*
		 * Synchronization is not required
		 * while the Term belongs to its Reducer.
		 */
		synchronized(this) {
			this.left = (TermImpl) left;
			this.left.parent = this;
		}
	}

	@Override
	public void clearLeft() {
		if (this.left == null)
			return;
		if (this.left.parent != this)
			throw new NoReciprocityException();
		
		this.left.parent = null;
		this.left = null;
	}

	@Override
	public Term getRight() {
		return this.right;
	}

	@Override
	public void setRight(Term right) {
		if (right == this.right)
			return;
		
		if (right == null) {
			this.clearRight();
			return;
		}
		
		if (this.reusePort != null)
			throw new IllegalStateException();
		if (this.right != null)
			throw new ClearFirstException();			
		if (right.getParent() != null)
			throw new NotAFreeTermException();
		
		/*
		 * Synchronization is not required
		 * while the Term belongs to its Reducer.
		 */
		synchronized(this) {
			this.right = (TermImpl) right;
			this.right.parent = this;
		}
	}

	@Override
	public void clearRight() {
		if (this.right == null)
			return;
		
		if (this.right.parent != this)
			throw new NoReciprocityException();
		
		synchronized (this) {
			this.right.parent = null;
			this.right = null;
		}
	}

	@Override
	public void clear() {
		this.clearLeft();
		this.clearRight();
	}
	
	@Override
	public boolean isCleared() {
		return (this.left == null && this.right == null);
	}

	@Override
	public boolean isBroken() {
		return (this.left == null || this.right == null
				|| this.left.isBroken() || this.right.isBroken());
	}

	@Override
	public int hashCode() {
		return 17567
				+ ((this.left != null) ? 6575543 * this.left.hashCode() : 0)
				+ ((this.right != null) ? 8765667 * this.right.hashCode() : 0);
	}
	
	@Override
	public boolean isNormalizable() {
		return this.left.isAbstraction() || this.right.isAbstraction();
	}

	@Override
	public String toDeBruijnString() {
		
		String leftString =
				(this.left != null) ? this.left.toDeBruijnString() : "□";
		if ((this.left != null && this.left.isAbstraction()))
			leftString = "(" + leftString + ")";

		String rightString =
				(this.right != null) ? this.right.toDeBruijnString() : "□";
		if ((this.right !=null) && this.right.isPair())
			rightString = "(" + rightString + ")";
		
		return leftString + " " + rightString;
	}
	
	@Override
	public String toDetailedDeBruijnString(Pair redex) {
		
		String leftString =
				(this.left != null) ? this.left.toDetailedDeBruijnString(redex) : "□";

		String rightString =
				(this.right != null) ? this.right.toDetailedDeBruijnString(redex) : "□";
		
		return (this == redex)
				? ("<<" + leftString + ">, <" + rightString + ">>")
				: ("[" + leftString + ", " + rightString + "]");
	}
}
