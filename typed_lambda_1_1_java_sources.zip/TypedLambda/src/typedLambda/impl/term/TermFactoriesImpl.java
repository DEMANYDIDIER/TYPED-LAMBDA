package typedLambda.impl.term;

import typedLambda.Test;
import typedLambda.model.term.Abstraction;
import typedLambda.model.term.Leaf;
import typedLambda.model.term.Pair;
import typedLambda.model.term.TermFactories;
import typedLambda.model.term.TermFactory;

public class TermFactoriesImpl implements TermFactories {

	public TermFactoriesImpl() {
	}

	@Override
	public TermFactory<Abstraction> getAbstractionFactory() {
		return Test.abstractionFactory;
	}

	@Override
	public TermFactory<Pair> getPairFactory() {
		return Test.pairFactory;
	}

	@Override
	public TermFactory<Leaf> getLeafFactory() {
		return Test.leafFactory;
	}

	@Override
	public final int getMemorySize() {
		return  this.getAbstractionFactory().getMemorySize()
				+ this.getPairFactory().getMemorySize()
				+ this.getLeafFactory().getMemorySize();
	}
}
