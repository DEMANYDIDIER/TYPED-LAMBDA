package typedLambda.impl.term;

import typedLambda.model.term.Abstraction;
import typedLambda.model.term.TermFactory;
import typedLambda.model.term.exception.NotAFreeTermException;

public class AbstractionFactoryImpl extends TermFactoryImpl<Abstraction> {
	public static final TermFactory<Abstraction> defaultTermFactory = new TermFactory<Abstraction>() {

		@Override
		public Abstraction newTerm() {
			return new AbstractionImpl();
		}

		@Override
		public void returnTerm(Abstraction term) throws NotAFreeTermException {
		}

		@Override
		public int getMemorySize() {
			return 0;
		}
	};

	@Override
	TermImpl defaultNewTerm() {
		return new AbstractionImpl();
	}

	@Override
	public final int termMemorySize() {
		return AbstractionImpl.abstractionSize;
	}
}
