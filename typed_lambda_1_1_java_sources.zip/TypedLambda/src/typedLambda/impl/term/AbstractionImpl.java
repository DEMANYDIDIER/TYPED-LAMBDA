package typedLambda.impl.term;

import typedLambda.model.term.Abstraction;
import typedLambda.model.term.Pair;
import typedLambda.model.term.Term;
import typedLambda.model.term.exception.ClearFirstException;
import typedLambda.model.term.exception.NoReciprocityException;
import typedLambda.model.term.exception.NotAFreeTermException;

public final class AbstractionImpl extends TermImpl implements Abstraction {
	public static final int abstractionSize = 6;

	TermImpl body = null;
	
	public AbstractionImpl() {
	}

	@Override
	public boolean isAbstraction() {
		return true;
	}

	@Override
	public boolean isLeaf() {
		return false;
	}

	@Override
	public boolean isPair() {
		return false;
	}

	@Override
	public Term getBody() {
		return this.body;
	}

	@Override
	public void setBody(Term body) {
		if (body == this.body)
			return;
		
		if (body == null) {
			this.clearBody();
			return;
		}
		
		if (this.reusePort != null)
			throw new IllegalStateException();
		if (this.body != null)
			throw new ClearFirstException();			
		if ( body.getParent() != null)
			throw new NotAFreeTermException();
		
		/*
		 * Synchronization is not required
		 * while the Term belongs to its Reducer.
		 */
		synchronized(this) {
			this.body = (TermImpl) body;
			this.body.parent = this;
		}
	}

	@Override
	public void clearBody() {
		if (this.body == null)
			return;
		if (this.body.parent != this)
			throw new NoReciprocityException();

		synchronized(this) {
			this.body.parent = null;
			this.body = null;
		}
	}

	@Override
	public void clear() {
		this.clearBody();
	}
	
	@Override
	public boolean isCleared() {
		return this.body == null;
	}

	@Override
	public boolean isBroken() {
		return (this.body == null || this.body.isBroken());
	}

	@Override
	public int hashCode() {
		return 3790647
				+ ((this.body != null) ? 754609 * this.body.hashCode() : 0);
	}
	
	@Override
	public String toDeBruijnString() {
		return this.body != null ?
				"λ " + this.body.toDeBruijnString() : "λ □";
	}
	
	@Override
	public String toDetailedDeBruijnString(Pair redex) {
		return this.body != null ?
				"λ " + this.body.toDetailedDeBruijnString(redex) : "λ □";
	}
}
