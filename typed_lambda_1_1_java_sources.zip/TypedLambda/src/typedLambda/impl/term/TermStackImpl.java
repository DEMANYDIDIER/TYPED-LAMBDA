package typedLambda.impl.term;

import java.util.Arrays;
import java.util.EmptyStackException;

import typedLambda.model.term.Term;
import typedLambda.model.term.TermStack;

public class TermStackImpl implements TermStack {
	private Term[] terms = new Term[1024];
	private int size = 0;
	
	public TermStackImpl() {
	}

	private void resize() {
		Term[] newTerms = new Term[2 * this.terms.length];
		System.arraycopy(terms, 0, newTerms, 0, terms.length);
		this.terms = newTerms;
	}
	
	@Override
	public void clear() {
		Arrays.fill(this.terms, 0, this.size, null);
		this.size = 0;
	}

	@Override
	public int size() {
		return this.size;
	}

	@Override
	public void add(Term term) {
		if (this.size == this.terms.length)
			this.resize();
		
		this.terms[this.size++] = term;
	}

	@Override
	public Term get(int k) {
		return this.terms[k];
	}

	@Override
	public Term top() {
		if (this.size == 0)
			throw new EmptyStackException();
		return this.terms[this.size - 1];
	}

	@Override
	public Term pop() {
		Term top = this.top();
		this.terms[--this.size] = null;
		return top;
	}
}
