					package typedLambda.impl.type;

import typedLambda.model.type.FunctionType;
import typedLambda.model.type.Type;

public final class FunctionTypeImpl extends TypeImpl implements FunctionType {
	public static final boolean TRACE = false;
	
	public static final FunctionTypeImpl FUNC = new FunctionTypeImpl('f', ANY_TYPE, ANY_TYPE);
	public static final FunctionTypeImpl BOOL = new FunctionTypeImpl('b', ANY_TYPE, FUNC);
	public static final FunctionTypeImpl INT = new FunctionTypeImpl('n', FUNC, FUNC);
	
	private final Type from;
	private final Type to;
	FunctionTypeImpl previous = null;

	public FunctionTypeImpl(char symbol, Type from, Type to) {
		super(symbol);
		this.from = from;
		this.to = to;
	}

	public FunctionTypeImpl(Type from, Type to) {
		this((char) 0, from, to);
	}
	
	@Override
	public final boolean isAnyType() {
		return false;
	}
	
	@Override
	public boolean isFunctionType() {
		return true;
		
	}

	@Override
	public final Type getFrom() {
		return this.from;
	}
	
	@Override
	public final Type getTo() {
		return this.to;
	}

	@Override
	public final boolean isAnyFunctionType() {
		return (this.from.isAnyType() && this.to.isAnyType());
	}
	
	@Override
	public final boolean isBooleanType() {
		return (this.from.isAnyType()
				&& this.to.isFunctionType() && ((FunctionType) this.to).isAnyFunctionType());
	}
	
	@Override
	public final boolean isNaturalType() {
		return (this.from.isFunctionType() && this.to.isFunctionType()
				&& ((FunctionType) this.from).isAnyFunctionType()
				&& ((FunctionType) this.to).isAnyFunctionType());
	}

	@Override
	public boolean isSameTypeThan(Type type) {
		if (type.isAnyType())
			return false;
		FunctionType functionType = (FunctionType) type;
		return this.from.isSameTypeThan(functionType.getFrom())
				&& this.to.isSameTypeThan(functionType.getTo());
	}
	
	@Override
	public boolean isSubTypeOfOrSameTypeThan(Type type) {
		if (type.isAnyType())
			return true;
		FunctionType functionType = (FunctionType) type;
		return this.from.isSubTypeOfOrSameTypeThan(functionType.getFrom())
				&& this.to.isSubTypeOfOrSameTypeThan(functionType.getTo());
	}
	
	@Override
	public int length() {
		return this.from.length() + this.to.length();
	}
	
	@Override
	public final String toString(boolean isCompact) {
		if (isCompact && this.isPredefined())
			return String.valueOf(this.symbol);
		boolean parenthesis = isCompact ?
				this.isPredefined() : !this.from.isAnyType();
		StringBuffer sb = new StringBuffer();
		if (parenthesis)
			sb.append("(");
		sb.append(this.from.toString(isCompact));
		if (parenthesis)
			sb.append(")");
		sb.append(" -> ");
		sb.append(this.to.toString(isCompact));
		return sb.toString();
	}
}
