package typedLambda.impl.substitute;

import typedLambda.model.substitute.BodySubstitution;
import typedLambda.model.term.Abstraction;
import typedLambda.model.term.Term;

public final class BodySubstitutionImpl
		extends SubstitutionImpl implements BodySubstitution {
	public static final int abstractionSubstitutionSize = 6;
	
	private Abstraction abstraction;

	public BodySubstitutionImpl() {
		super();
	}

	@Override
	public final boolean isNull() {
		return this.abstraction == null;
	}
	
	@Override
	public final boolean isBodySubstitution() {
		return true;
	}

	@Override
	public final void clear() {
		super.clear();
		this.abstraction = null;
	}

	@Override
	public final Term getParentTerm() {
		return this.abstraction;
	}

	@Override
	public final Abstraction getAbstraction() {
		return this.abstraction;
	}
	
	@Override
	public final void setAbstraction(Abstraction abstraction) {
		if (this.abstraction != null)
			throw new IllegalStateException();
		this.abstraction = abstraction;
	}

	@Override
	public final void substituteBy(Term term) {
		this.abstraction.setBody(term);
	}
}
