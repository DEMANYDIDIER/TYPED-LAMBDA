package typedLambda.impl.substitute;

import typedLambda.Test;
import typedLambda.model.substitute.BodySubstitution;
import typedLambda.model.substitute.PairSubstitution;
import typedLambda.model.substitute.SubstitutionFactories;
import typedLambda.model.substitute.SubstitutionFactory;

public class SubstitutionFactoriesImpl implements SubstitutionFactories {

	public SubstitutionFactoriesImpl() {
	}

	@Override
	public SubstitutionFactory<BodySubstitution> getBodySubstitutionFactory() {
		return Test.abstractionSubstitutionFactory;
	}

	@Override
	public SubstitutionFactory<PairSubstitution> getLeftSubstitutionFactory() {
		return Test.leftSubstitutionFactory;
	}

	@Override
	public SubstitutionFactory<PairSubstitution> getRightSubstitutionFactory() {
		return Test.rightSubstitutionFactory;
	}

	@Override
	public final int getMemorySize() {
		return this.getBodySubstitutionFactory().getMemorySize()
			+ this.getLeftSubstitutionFactory().getMemorySize()
			+ this.getRightSubstitutionFactory().getMemorySize();
	}
}
