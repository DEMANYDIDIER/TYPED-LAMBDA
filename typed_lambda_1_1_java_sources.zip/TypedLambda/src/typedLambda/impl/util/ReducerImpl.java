package typedLambda.impl.util;

import typedLambda.impl.substitute.SubstitutionImpl;
import typedLambda.impl.term.AbstractionImpl;
import typedLambda.impl.term.TermImpl;
import typedLambda.impl.term.TermStackImpl;
import typedLambda.model.substitute.BodySubstitution;
import typedLambda.model.substitute.PairSubstitution;
import typedLambda.model.substitute.Substitution;
import typedLambda.model.substitute.SubstitutionFactory;
import typedLambda.model.term.Abstraction;
import typedLambda.model.term.Leaf;
import typedLambda.model.term.Pair;
import typedLambda.model.term.Term;
import typedLambda.model.term.TermFactory;
import typedLambda.model.term.TermStack;
import typedLambda.model.term.exception.AbstractionNotFoundException;
import typedLambda.model.term.exception.UnexpectedTermException;
import typedLambda.model.util.Collector;
import typedLambda.model.util.NormalizationStatistics;
import typedLambda.model.util.Reducer;
import typedLambda.model.util.exception.reduce.TooMuchBetaReductionException;

public class ReducerImpl implements Reducer {
	public static boolean TRACE = false;

	private static final String termPosition(Term term) {
		StringBuffer sb = new StringBuffer();
		while (true) {
			Term parent = term.getParent();
			if (parent == null)
				break;
			String relation;
			if (parent.isAbstraction())
				relation = "A";
			else if (parent.isPair()) {
				Pair pair = (Pair) parent;
				if (term == pair.getLeft())
					relation = "0";
				else if (term == pair.getRight())
					relation = "1";
				else
					throw new IllegalStateException();
			} else
				throw new UnexpectedTermException();
			sb.insert(0, relation);
			term = parent;
		}
		sb.insert(0, "\"");
		sb.append("\"");
		return sb.toString();
	}

	private static final Term getCopy(Term containerTerm, Term containerCopy,
			final Term arg) {

		while (true) {
			/*
			 * containerCopy is clone of containerTerm.
			 * arg belongs to containerTerm.
			 * returns a clone of arg.
			 */
			if (arg == containerTerm)
				return containerCopy;

			Term term = arg;

			while (true) {
				/*
				 * term belongs to containerTerm.
				 */
				Term parent = term.getParent();

				if (parent == null)
					throw new IllegalStateException();

				if (parent == containerTerm)
					break;

				term = parent;
			}
			/*
			 * term is child of containerTerm.
			 */

			if (containerTerm.isAbstraction()) {
				Abstraction termAbstraction = (Abstraction) containerTerm;
				Abstraction copyAbstraction = (Abstraction) containerCopy;

				containerTerm = termAbstraction.getBody();
				containerCopy = copyAbstraction.getBody();

			} else if (containerTerm.isPair()) {
				Pair termPair = (Pair) containerTerm;
				Pair copyPair = (Pair) containerCopy;

				if (term == termPair.getLeft()) {
					containerTerm = termPair.getLeft();
					containerCopy = copyPair.getLeft();

				} else if (term == termPair.getRight()) {
					containerTerm = termPair.getRight();
					containerCopy = copyPair.getRight();
				} else
					throw new IllegalStateException();
			} else
				throw new UnexpectedTermException();
		}
	}

	private static final void decrementFreeDBIndexes(Term container) {
		if (container == null)
			throw new IllegalArgumentException();
	
		Term term = container;
		Term backFrom = null;
	
		while (term != null) {
	
			if (term.isLeaf()) {
				Leaf leaf = (Leaf) term;
				leaf.decrementDBIndexIfFree();
				backFrom = term;
				term = term.getParent();
	
			} else if (term.isAbstraction()) {
				if (backFrom == null) {
					Abstraction abstraction = (Abstraction) term;
					term = abstraction.getBody();
					;
				} else {
					backFrom = term;
					term = term.getParent();
				}
	
			} else if (term.isPair()) {
				Pair pair = (Pair) term;
				if (backFrom == null) {
					term = pair.getLeft();
				} else {
					if (backFrom == pair.getLeft()) {
						Term right = pair.getRight();
						term = right;
						backFrom = null;
					} else if (backFrom == pair.getRight()) {
						backFrom = term;
						term = term.getParent();
					} else
						throw new IllegalStateException();
				}
			} else
				throw new UnexpectedTermException();
		}
	}

	private static final void incrementFreeDBIndexes(
			Term container, int count) {
		if (container == null)
			throw new IllegalArgumentException();
	
		Term term = container;
		Term backFrom = null;
	
		while (term != null) {
	
			if (term.isLeaf()) {
				Leaf leaf = (Leaf) term;
				leaf.incrementDBIndexIfFree(count);
				backFrom = term;
				term = term.getParent();
	
			} else if (term.isAbstraction()) {
				if (backFrom == null) {
					Abstraction abstraction = (Abstraction) term;
					term = abstraction.getBody();
					;
				} else {
					backFrom = term;
					term = term.getParent();
				}
	
			} else if (term.isPair()) {
				Pair pair = (Pair) term;
				if (backFrom == null) {
					term = pair.getLeft();
				} else {
					if (backFrom == pair.getLeft()) {
						Term right = pair.getRight();
						term = right;
						backFrom = null;
					} else if (backFrom == pair.getRight()) {
						backFrom = term;
						term = term.getParent();
					} else
						throw new IllegalStateException();
				}
			} else
				throw new UnexpectedTermException();
		}
	}

	private final Collector collector;
	private final long maxBetaReduction;
	
	private final TermFactory<Abstraction> abstractionFactory;
	private final TermFactory<Pair> pairFactory;
	private final TermFactory<Leaf> leafFactory;

	private final SubstitutionFactory<BodySubstitution> bodySubstitutionFactory;
	private final SubstitutionFactory<PairSubstitution> leftSubstitutionFactory;
	private final SubstitutionFactory<PairSubstitution> rightSubstitutionFactory;

	private final Substitution substitutionList = new SubstitutionImpl();
	private final Abstraction capsule = new AbstractionImpl();
	private final NormalizationStatistics normalizationStatistics =
			new NormalizationStatistics();

	public ReducerImpl(Collector collector, long maxBetaReduction) {
		this.collector = collector;
		this.maxBetaReduction = maxBetaReduction;
		
		this.abstractionFactory = TermImpl.termFactories.getAbstractionFactory();
		this.pairFactory = TermImpl.termFactories.getPairFactory();
		this.leafFactory = TermImpl.termFactories.getLeafFactory();

		this.bodySubstitutionFactory = SubstitutionImpl.substitutionFactories.getBodySubstitutionFactory();
		this.leftSubstitutionFactory = SubstitutionImpl.substitutionFactories.getLeftSubstitutionFactory();
		this.rightSubstitutionFactory = SubstitutionImpl.substitutionFactories.getRightSubstitutionFactory();

		this.substitutionList.setPrevious(this.substitutionList);
	}

	private final int substitutionCount() {
		if (!this.substitutionList.isNull())
			throw new IllegalArgumentException();

		Substitution substitution =
				this.substitutionList.getPrevious(); // top of stack

		int count = 0;

		while (!substitution.isNull()) {
			count++;
			substitution = substitution.getPrevious();
		}
		return count;
	}

	private final void forAllSubstituteByNull() {
		if (!this.substitutionList.isNull())
			throw new IllegalArgumentException();
	
		Substitution substitution =
				this.substitutionList.getPrevious(); // top of stack
	
		while (!substitution.isNull()) {
			substitution.substituteBy(null);
			substitution = substitution.getPrevious();
		}
	}

	private final void storeSubstitutionList(Term container, Abstraction target) {
	
		if (container == null || target == null)
			throw new IllegalArgumentException();
		if (!this.substitutionList.isNull())
			throw new IllegalArgumentException();
	
		this.substitutionList.setPrevious(this.substitutionList);
	
		Term term = container;
		Term backFrom = null;
	
		while (term != null) {
	
			if (term.isLeaf()) {
				backFrom = term;
				term = term.getParent();
	
			} else if (term.isAbstraction()) {
				if (backFrom == null) {
					Abstraction abstraction = (Abstraction) term;
					Term body = abstraction.getBody();
					if (body.isLeaf()) {
						Leaf leaf = (Leaf) body;
						if (leaf.getTarget() == target) {
							if (TRACE)
								System.out.println(termPosition(leaf));
							BodySubstitution substitution = this.bodySubstitutionFactory.newSubstitution();
							substitution.setAbstraction(abstraction);
							Substitution top = this.substitutionList.getPrevious(); // old top of stack
							substitution.setPrevious(top);
							this.substitutionList.setPrevious(substitution); // new top of stack
						}
					}
					term = body;
				} else {
					backFrom = term;
					term = term.getParent();
				}
	
			} else if (term.isPair()) {
				Pair pair = (Pair) term;
				if (backFrom == null) {
					Term left = pair.getLeft();
					Term right = pair.getRight();
					if (left.isLeaf()) {
						Leaf leaf = (Leaf) left;
						if (leaf.getTarget() == target) {
							if (TRACE)
								System.out.println(termPosition(leaf));
							PairSubstitution substitution = this.leftSubstitutionFactory.newSubstitution();
							substitution.setPair(pair);
							Substitution top = this.substitutionList.getPrevious(); // old top of stack
							substitution.setPrevious(top);
							this.substitutionList.setPrevious(substitution); // new top of stack
						}
					}
					if (right.isLeaf()) {
						Leaf leaf = (Leaf) right;
						if (leaf.getTarget() == target) {
							if (TRACE)
								System.out.println(termPosition(leaf));
							PairSubstitution substitution = this.rightSubstitutionFactory.newSubstitution();
							substitution.setPair(pair);
							Substitution top = this.substitutionList.getPrevious(); // old top of stack
							substitution.setPrevious(top);
							this.substitutionList.setPrevious(substitution); // new top of stack
						}
					}
					term = left;
				} else {
					if (backFrom == pair.getLeft()) {
						term = pair.getRight();
						backFrom = null;
					} else if (backFrom == pair.getRight()) {
						backFrom = term;
						term = term.getParent();
					} else
						throw new IllegalStateException();
				}
			} else
				throw new UnexpectedTermException();
		}
	}

	private final void forAllSubstituteByArgument(Term argumentModel) {
		if (!this.substitutionList.isNull())
			throw new IllegalArgumentException();
		if (argumentModel == null)
			throw new IllegalArgumentException();
	
		Substitution substitution =
				this.substitutionList.getPrevious(); // top of stack
		int n = substitutionCount();
		
		while (!substitution.isNull()) {
			int bindersCount = substitution.bindersCount();
			Term argument = (n > 1) ? cloneTerm(argumentModel) : argumentModel;
			if (bindersCount > 0)
				incrementFreeDBIndexes(argument, bindersCount);
			substitution.substituteBy(argument);
			substitution = substitution.getPrevious();
			n--;
		}
		if (n != 0)
			throw new IllegalStateException();
	}

	/*
	 * xλy.M -> λy.xM
	 */
	private final void abstractionGoesUp(Pair pair) {
		if (pair == null)
			throw new IllegalArgumentException();
		
		if (!pair.getRight().isAbstraction())
			return;
		
		Abstraction abstraction = (Abstraction) pair.getRight();
		Term nextTerm = abstraction.getBody();

		Substitution substitution = this.collector.newSubstitution(pair);
		substitution.substituteBy(null);
		
		pair.clearRight();
		abstraction.clearBody();
		
		incrementFreeDBIndexes(pair.getLeft(), 1);
		
		substitution.substituteBy(abstraction);
		substitution.clear();
		this.collector.returnSubstitutionToFactory(substitution);

		abstraction.setBody(pair);
		pair.setRight(nextTerm);
	}

	@Override
	public final void verifyClosure(Abstraction hand, Abstraction before)
			throws AbstractionNotFoundException {
		Term term = hand;
		TermStack termStack = new TermStackImpl();
		
		while (true) {
			if (term.isAbstraction()) {
				Abstraction abstraction = (Abstraction) term;
				term = abstraction.getBody();
			} else if (term.isLeaf()) {
				Leaf leaf = (Leaf) term;
				if (leaf.getTarget()== null)
					throw new AbstractionNotFoundException(before, hand);
				if (termStack.size() == 0)
					break;
				term = termStack.pop();
			} else if (term.isPair()) {
				Pair pair = (Pair) term;
				termStack.add(pair.getRight());
				term = pair.getLeft();
				continue;
			} else
				throw new UnexpectedTermException();
		}
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public final <T extends Term> T cloneTerm(T container) {
		if (container == null)
			throw new IllegalArgumentException();

		/*
		 * Build left chain.
		 */
		Leaf termLeaf = this.collector.leftmostLeaf(container);
		Leaf copyLeaf = (Leaf) this.leafFactory.newTerm();
		{
			int dBIndex = termLeaf.getDBIndex();
			copyLeaf.setDBIndex(dBIndex);
		}

		Term term = termLeaf;
		Term copy = copyLeaf;

		while (true) {
			Term termParent = term.getParent();
			Term copyParent = null;

			if (termParent == null)
				break;

			if (termParent.isAbstraction()) {
				Abstraction abstraction = this.abstractionFactory.newTerm();
				abstraction.setBody(copy);
				copyParent = abstraction;

			} else if (termParent.isPair()) {
				Pair pair = this.pairFactory.newTerm();
				pair.setLeft(copy);
				copyParent = pair;

			} else
				throw new UnexpectedTermException();

			term = termParent;
			copy = copyParent;
		}
		Term containerTerm = term;
		Term containerCopy = copy;

		if (containerTerm != container)
			throw new IllegalStateException();

		while (true) {

			/*
			 * Leftmost parent.
			 */
			term = termLeaf;

			while (true) {
				Term termParent = term.getParent();

				if (termParent == null)
					break;

				if (termParent.isPair() && term == ((Pair) termParent).getLeft())
					break;

				term = termParent;
			}

			/*
			 * Up and right.
			 */
			term = term.getParent();

			if (term == null)
				break;

			term = ((Pair) term).getRight();

			/*
			 * Leftmost leaf
			 */
			termLeaf = this.collector.leftmostLeaf(term);

			/*
			 * Next leaf.
			 */
			copyLeaf = this.leafFactory.newTerm();
			{
				int dBIndex = termLeaf.getDBIndex();
				copyLeaf.setDBIndex(dBIndex);
			}

			/*
			 * Build left chain
			 */
			term = termLeaf;
			copy = copyLeaf;

			while (true) {
				Term termParent = term.getParent();
				Term copyParent = null;

				if (termParent == null)
					break;

				if (termParent.isAbstraction()) {
					Abstraction abstraction = this.abstractionFactory.newTerm();
					abstraction.setBody(copy);
					copyParent = abstraction;

				} else if (termParent.isPair()) {
					Pair termParentPair = (Pair) termParent;
					if (term == termParentPair.getLeft()) {
						Pair pair = this.pairFactory.newTerm();
						pair.setLeft(copy);
						copyParent = pair;

					} else if (term == termParentPair.getRight())
						break;
					else
						throw new IllegalStateException();
				} else
					throw new UnexpectedTermException();

				term = termParent;
				copy = copyParent;
			}

			Term parentTerm = term.getParent();
			Term parentCopy = getCopy(containerTerm, containerCopy, parentTerm);

			((Pair) parentCopy).setRight(copy);
		}

		/*
		 * Existence of the rightest leaf.
		 */
		this.collector.rightmostLeaf(containerCopy);

		return (T) containerCopy;
	}

	@Override
	public Pair leftmostNormalizablePair(Term container) {
		if (container == null)
			throw new IllegalArgumentException();

		Term term = container;
		Term backFrom = null;

		while (term != null) {

			if (term.isLeaf()) {
				backFrom = term;
				term = term.getParent();

			} else if (term.isAbstraction()) {
				if (backFrom == null) {
					Abstraction abstraction = (Abstraction) term;
					term = abstraction.getBody();
					;
				} else {
					backFrom = term;
					term = term.getParent();
				}

			} else if (term.isPair()) {
				Pair pair = (Pair) term;
				if (backFrom == null) {
					if (pair.isNormalizable())
						return pair;
					term = pair.getLeft();
				} else {
					if (backFrom == pair.getLeft()) {
						term = pair.getRight();
						backFrom = null;
					} else if (backFrom == pair.getRight()) {
						backFrom = term;
						term = term.getParent();
					} else
						throw new IllegalStateException();
				}
			} else
				throw new UnexpectedTermException();
		}
		return null;
	}
	
	@Override
	public final int reduceRedex(Abstraction container, Pair redex) {
		if (container == null || redex == null
				|| !redex.getLeft().isAbstraction())
			throw new IllegalArgumentException();
		
		Substitution redexSubstitution = this.collector.newSubstitution(redex);

		Abstraction target = (Abstraction) redex.getLeft();
		Term argumentModel = redex.getRight();
		Term body = target.getBody();

		this.substitutionList.setPrevious(this.substitutionList);
		this.storeSubstitutionList(body, target);
		int substitutionCount = substitutionCount();
		if (TRACE && substitutionCount ==  0)
			System.out.println(String.valueOf(substitutionCount)
					+ "substitution");

		redex.clear();
		target.clearBody();

		forAllSubstituteByNull();

		decrementFreeDBIndexes(body);

		if (substitutionCount > 0) {
			forAllSubstituteByArgument(argumentModel);
			argumentModel = null;
		}
		
		redexSubstitution.substituteBy(null);
		redexSubstitution.substituteBy(body);
		
		redexSubstitution.clear();
		this.collector.returnSubstitutionToFactory(redexSubstitution);

		this.collector.returnSubstitutionListToFactory(this.substitutionList);
		
		if (argumentModel != null)
			this.collector.returnArgumentToFactory(argumentModel);
		
		this.pairFactory.returnTerm(redex);
		this.abstractionFactory.returnTerm(target);

		return substitutionCount;
	}

	@Override
	public final Term reduceRedex(Pair redex) {
		if (redex == null || !redex.getLeft().isAbstraction())
			throw new IllegalArgumentException();
		if (!this.capsule.isCleared() || this.capsule.getParent() != null)
			throw new IllegalStateException();

		this.capsule.setBody(redex);

		this.reduceRedex(this.capsule, redex);
		Term result = this.capsule.getBody();

		this.capsule.clear();
		return result;
	}

	@Override
	public final NormalizationStatistics normalize(Abstraction container)
			throws TooMuchBetaReductionException {
		if (container == null)
			throw new IllegalArgumentException();

		int reductionCount = 0;
		int substitutionCount = 0;
		int goingUpCount = 0;

		while (true) {
			Pair normalizablePair = this.leftmostNormalizablePair(container);
			
			if (normalizablePair == null)
				break;
			
			if (normalizablePair.getLeft().isAbstraction()) {
				if (TRACE)
					System.out.println("redex   "
							+ container.toDetailedDeBruijnString(normalizablePair));
				
				substitutionCount += this.reduceRedex(container, normalizablePair);
				reductionCount++;
				if (reductionCount > this.maxBetaReduction)
					throw new TooMuchBetaReductionException();

			} else if (normalizablePair.getRight().isAbstraction()) {
				if (TRACE)
					System.out.println("goingUp "
							+ container.toDetailedDeBruijnString(normalizablePair));
				
				this.abstractionGoesUp(normalizablePair);
				goingUpCount++;

			} else
				throw new IllegalStateException();
		}
		
		this.normalizationStatistics.reductionCount = reductionCount;
		this.normalizationStatistics.substitutionCount = substitutionCount;
		this.normalizationStatistics.goingUpCount = goingUpCount;

		return this.normalizationStatistics;
	}

	@Override
	public final Term normalize(Pair container)
			throws TooMuchBetaReductionException {
		if (container == null)
			throw new IllegalArgumentException();

		if (!this.capsule.isCleared() || this.capsule.getParent() != null)
			throw new IllegalStateException();

		this.capsule.setBody(container);

		this.normalize(this.capsule);

		Term newContainer = this.capsule.getBody();
		this.capsule.clear();

		return newContainer;
	}

	@Override
	public final NormalizationStatistics lastNormalization() {
		return this.normalizationStatistics;
	}
}
