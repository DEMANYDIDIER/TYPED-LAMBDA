package typedLambda.impl.util;

import typedLambda.impl.term.TermImpl;
import typedLambda.model.term.Abstraction;
import typedLambda.model.term.Leaf;
import typedLambda.model.term.Pair;
import typedLambda.model.term.Term;
import typedLambda.model.term.TermFactory;
import typedLambda.model.term.exception.BrokenArgumentException;
import typedLambda.model.util.StructureBuilder;
import typedLambda.model.util.exception.ReconnectionNotPossibleException;

public class StructureBuilderImpl implements StructureBuilder {
	
	private final TermFactory<Abstraction> abstractionFactory;
	private final TermFactory<Pair> pairFactory;
	private final TermFactory<Leaf> leafFactory;

	public StructureBuilderImpl() {
		this.abstractionFactory = TermImpl.termFactories.getAbstractionFactory();
		this.pairFactory = TermImpl.termFactories.getPairFactory();
		this.leafFactory = TermImpl.termFactories.getLeafFactory();
	}
	
	@Override
	public Abstraction newIdentity() {
		Abstraction abstraction = this.abstractionFactory.newTerm();
		Leaf leaf = this.leafFactory.newTerm();
		leaf.setDBIndex(1);
		abstraction.setBody(leaf);
		return abstraction;
	}
	
	@Override
	public Abstraction newBoolean(boolean value) {
		Abstraction abstractionX = this.abstractionFactory.newTerm();
		Abstraction abstractionY = this.abstractionFactory.newTerm();
		Leaf leaf = this.leafFactory.newTerm();
		leaf.setDBIndex(value ? 2 : 1);
		abstractionY.setBody(leaf);
		abstractionX.setBody(abstractionY);
		return abstractionX;
	}
	
	@Override
	public void permutBoolean(Abstraction hand) {
		Abstraction abstractionY = (Abstraction) hand.getBody();
		Leaf leaf = (Leaf) abstractionY.getBody();
		int dBindex = leaf.getDBIndex();
		leaf.setDBIndex(dBindex == 1 ? 2 : 1);
	}
	
	@Override
	public final Abstraction newNumeral(int n) {
		if (n < 0)
			throw new IllegalArgumentException();
		
		Leaf leaf_x = this.leafFactory.newTerm();
		leaf_x.setDBIndex(1);
		Term term = leaf_x;
		
		while (n-- > 0) {
			
			Leaf leaf_f = this.leafFactory.newTerm();
			leaf_f.setDBIndex(2);
			
			Pair pair = this.pairFactory.newTerm();
			pair.setLeft(leaf_f);
			pair.setRight(term);
			term = pair;
		}
		
		Abstraction abstraction_x = this.abstractionFactory.newTerm();
		abstraction_x.setBody(term);
		
		Abstraction abstraction_f = this.abstractionFactory.newTerm();
		abstraction_f.setBody(abstraction_x);
		
		return abstraction_f;
	}

	@Override
	public Abstraction newOneAmongstSeveral(int n) {
		if (n < 1)
			throw new IllegalArgumentException();
		
		Abstraction[] abstractions = new Abstraction[n];
		for (int k = 0; k < n; k++)
			abstractions[k] = this.abstractionFactory.newTerm();
		for (int k = n - 2; k >= 0; k--)
			abstractions[k].setBody(abstractions[k + 1]);
		
		Leaf leaf = this.leafFactory.newTerm();
		leaf.setDBIndex(n);
		abstractions[n - 1].setBody(leaf);
		
		return abstractions[0];
	}

	@Override
	public Abstraction newSeveralAmongstSeveral(int n, int p) {
		if (n < 1 || p < 1 || p > n)
			throw new IllegalArgumentException();
		if (p == 1)
			return this.newOneAmongstSeveral(n);
		
		Abstraction[] abstractions = new Abstraction[n];
		for (int k = 0; k < n; k++)
			abstractions[k] = this.abstractionFactory.newTerm();
		for (int k = n - 2; k >= 0; k--)
			abstractions[k].setBody(abstractions[k + 1]);
		
		Leaf[] leaves = new Leaf[p];
		for (int k = 0; k < p; k++) {
			Leaf leaf= this.leafFactory.newTerm();
			leaves[k] = leaf;
			leaf.setDBIndex(n - k);
		}
		
		Pair[] pairs = new Pair[p - 1];
		for (int k = 0; k < p -1; k++) {
			Pair pair = this.pairFactory.newTerm();
			pairs[k] = pair;
			pair.setLeft(leaves[k]);
		}
		for (int k = 0; k < p - 2; k ++)
			pairs[k].setRight(pairs[k + 1]);
		pairs[p - 2].setRight(leaves[p - 1]);
		
		abstractions[n - 1].setBody(pairs[0]);
		
		return abstractions[0];
	}

	@Override
	public void reconnect(Abstraction hand, Leaf leaf, Abstraction newTarget)
		throws ReconnectionNotPossibleException {
		leaf.setDBIndex(newTarget);
	}

	@Override
	public Abstraction newCouple(Term component1, Term component2) {
		if (component1 == null || component2 == null)
			throw new IllegalArgumentException();
		if (component1.isBroken() || component2.isBroken())
			throw new BrokenArgumentException();

		Leaf leaf = this.leafFactory.newTerm();
		leaf.setDBIndex(1);
		
		Pair pair1 = this.pairFactory.newTerm();
		pair1.setLeft(leaf);
		pair1.setRight(component1);
		
		Pair pair2 = this.pairFactory.newTerm();
		pair2.setLeft(pair1);
		pair2.setRight(component2);
		
		Abstraction abstraction = this.abstractionFactory.newTerm();
		abstraction.setBody(pair2);
		return abstraction;
	}
	
	@Override
	public Abstraction newList(Term[] elements) {
		Leaf leaf_x = this.leafFactory.newTerm();
		leaf_x.setDBIndex(1);
		Term term = leaf_x;
		
		for (int k = elements.length - 1; k >= 0; k--) {
			Term element = elements[k];
			
			Leaf leaf_f = this.leafFactory.newTerm();
			leaf_f.setDBIndex(2);
			
			Pair pair1 = this.pairFactory.newTerm();
			pair1.setLeft(leaf_f);
			pair1.setRight(element);
			
			Pair pair2 = this.pairFactory.newTerm();
			pair2.setLeft(pair1);
			pair2.setRight(term);
			
			term = pair2;
		}
		
		Abstraction abstraction_x = this.abstractionFactory.newTerm();
		abstraction_x.setBody(term);
		
		Abstraction abstraction_f = this.abstractionFactory.newTerm();
		abstraction_f.setBody(abstraction_x);
		
		return abstraction_f;
	}

	@Override
	public Abstraction newApplication(Abstraction function, Term argument) {
		Pair pair = this.pairFactory.newTerm();
		pair.setLeft(function);
		pair.setRight(argument);
		
		Abstraction abstraction = this.abstractionFactory.newTerm();
		abstraction.setBody(pair);
		return abstraction;
	}
}
