package typedLambda.impl.util;

import java.io.PrintStream;

import typedLambda.model.term.Abstraction;
import typedLambda.model.type.FunctionType;
import typedLambda.model.type.FunctionTypeBase;
import typedLambda.model.type.Type;
import typedLambda.model.type.exception.UntypedTermException;
import typedLambda.model.util.Inferencer;
import typedLambda.model.util.TypeAssigner;
import typedLambda.model.util.exception.NotInNormalFormException;

public class TypeAssignerImpl implements TypeAssigner {
	static final boolean TRACE = InferencerImpl.TRACE;
	
	private final FunctionTypeBase functionTypeBase;
	private final Type rootType;
	
	private int lastStepCount = 0;
	private int lastNodeUpdateCount = 0;
	
	public TypeAssignerImpl(FunctionTypeBase functionTypeBase, Type rootType) {
		this.functionTypeBase = functionTypeBase;
		this.rootType = rootType;
	}

	@Override
	public final FunctionType assignType(Abstraction combinatorHand, PrintStream reasoning)
			throws NotInNormalFormException {
		if (combinatorHand == null)
			throw new IllegalArgumentException();
		
		if (TRACE)
			System.out.println(combinatorHand.toDetailedDeBruijnString(null));
		
		if (reasoning != null) {
			String literal = ConverterFromTree.convertToLiteral(combinatorHand);
			reasoning.println("Type assignment of " + literal.toString());
		}
		
		Inferencer inferencer =
				new InferencerImpl(this.functionTypeBase, this.rootType,
						combinatorHand, reasoning, false);
		
		int stepCount = 0;
		int nodeUpdateCount = 0;

		try {
			while (true) {
				if (reasoning != null)
					reasoning.println("application rules step "
							+ String.valueOf(1 + stepCount));
				
				boolean isTerminated = inferencer.applyApplicationRules();

				stepCount++;
				for (int k = 0; k < inferencer.getNodeCount(); k++)
					if (inferencer.isNodeTypeUpdated(k))
						nodeUpdateCount++;

				if (TRACE) {
					StringBuffer sb = new StringBuffer();
					for (int k = 0; k < inferencer.getNodeCount(); k++) {
						if (k == inferencer.getAbstractionCount())
							sb.append(" ");
						sb.append(inferencer.isNodeTypeUpdated(k) ? "1" : "0");
					}
					System.out.println(sb.toString());
				}

				if (isTerminated)
					break;
			}
			this.lastStepCount = stepCount;
			this.lastNodeUpdateCount = nodeUpdateCount;

			return inferencer.applyAbstractionRules();
		} catch (UntypedTermException e) {}
		return null;
	}

	@Override
	public final FunctionType assignType(Abstraction combinatorHand)
			throws NotInNormalFormException {
		return this.assignType(combinatorHand, null);
	}
	
	@Override
	public final int  getLastStepCount() {
		return this.lastStepCount;
	}
	
	@Override
	public final int getLastPairUpdateCount() {
		return this.lastNodeUpdateCount;
	}
}
