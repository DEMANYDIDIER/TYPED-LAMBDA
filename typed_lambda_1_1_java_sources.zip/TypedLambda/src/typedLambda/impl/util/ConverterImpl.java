package typedLambda.impl.util;

import typedLambda.common.Literal;
import typedLambda.impl.term.TermImpl;
import typedLambda.model.term.Abstraction;
import typedLambda.model.term.Leaf;
import typedLambda.model.term.Pair;
import typedLambda.model.term.Term;
import typedLambda.model.term.TermFactory;
import typedLambda.model.util.ConverterToTree;
import typedLambda.model.util.exception.convert.IndexExpectedException;
import typedLambda.model.util.exception.convert.TooMutchClosingException;
import typedLambda.model.util.exception.convert.UncompleteExpressionException;

public class ConverterImpl implements ConverterToTree {
	public static final boolean TRACE = false;
	
	@Override
	public final Abstraction convertClassicToTree(Literal literal) {
		
		int abstractionCount = literal.abstractionCount;
		Abstraction[] abstractions = new Abstraction[literal.abstractionCount];
		
		int leafCount = literal.getLeafCount();
		Leaf[] leaves = new Leaf[leafCount];
		for (int k = 0; k < leafCount; k++)
			leaves[k] = this.leafFactory.newTerm();
		int[] abstractionIndexes = new int[leafCount];
		int leafIndex = 0;
		
		Term[] termStack = new Term[27];
		int stackIndex = 0;
		
		String expression = literal.expression;
		int charIndex = 0;
		
		while (charIndex < expression.length()) {
			char ch = expression.charAt(charIndex++);
			if (ch == '(') {
				stackIndex++;
			} else if (ch == ')') {
				if (stackIndex == 0)
					throw new TooMutchClosingException(expression);
				if (termStack[stackIndex] == null)
					stackIndex--;
				else {
					Term argTerm = termStack[stackIndex];
					termStack[stackIndex--] = null;
					Pair pair = this.pairFactory.newTerm();
					pair.setLeft(termStack[stackIndex]);
					pair.setRight(argTerm);
					termStack[stackIndex] = pair;
				}
			} else {
				int absIndex = (ch - 'a');
				abstractionIndexes[leafIndex] = absIndex;
				Term argTerm = leaves[leafIndex++];
				Term term =  argTerm;
				if (termStack[stackIndex] != null) {
					Pair pair = this.pairFactory.newTerm();
					pair.setLeft(termStack[stackIndex]);
					pair.setRight(argTerm);
					term = pair;
				}
				termStack[stackIndex] = term;
			}
		}
		if (stackIndex > 0)
			throw new UncompleteExpressionException(expression);
		
		Term hand = termStack[0];
		for (int absIndex = abstractionCount - 1;
				absIndex >= 0; absIndex--) {
			Abstraction abstraction = this.abstractionFactory.newTerm();
			abstraction.setBody(hand);
			abstractions[absIndex] = abstraction;

			if (TRACE)
				System.out.println("Abstraction(" 
						+ String.valueOf(absIndex) + ") : "
						+ abstraction.toString());
			
			hand = abstraction;
		}
		
		for (int varIndex = 0; varIndex < leafCount; varIndex++) {
			int absIndex = abstractionIndexes[varIndex];
			Leaf leaf = leaves[varIndex];
			Abstraction target = abstractions[absIndex];
			
			if (TRACE)
				System.out.println("Leaf(" + String.valueOf(varIndex)
					+ " , " + String.valueOf(absIndex) + ") : "
						+ leaf.toString());
			
			leaf.setDBIndex(target);
		}
		
		return abstractions[0];
	}

	@Override
	public final Term  convertDeBrujnToTree(String literal) {
		Term[] termStack= new Term[30];
		int[] absCountStack = new int[30];
		
		int stackIndex = 0;
		int charIndex = 0;
		
		while (charIndex < literal.length()) {
			char ch = literal.charAt(charIndex++);
			
			if (ch == ' ')
				continue;
			
			if (ch == '(') {
				stackIndex++;
				
			} else if (ch == ')') {
				if (stackIndex == 0)
					throw new TooMutchClosingException(literal);
				
				if (termStack[stackIndex] == null)
					stackIndex--;
				else {
					Term argTerm = termStack[stackIndex];
					
					for (int k = 0; k < absCountStack[stackIndex]; k++) {
						Abstraction abstraction = this.abstractionFactory.newTerm();
						abstraction.setBody(argTerm);
						argTerm = abstraction;	
					}
					termStack[stackIndex] = null;
					absCountStack[stackIndex] = 0;
					stackIndex--;
					
					if (termStack[stackIndex] != null) {
						Pair pair = this.pairFactory.newTerm();
						pair.setLeft(termStack[stackIndex]);
						pair.setRight(argTerm);
						termStack[stackIndex] = pair;
					} else
						termStack[stackIndex] =  argTerm;
				}
			} else if (ch == '\\' || ch == 'λ') {
				if (termStack[stackIndex] != null)
					stackIndex++;
				absCountStack[stackIndex]++;
				
			} else {
				int dBIndex = (ch - '0');
				if (ch > '9')
					throw new IndexExpectedException(literal);
				
				while (charIndex < literal.length()
						&& literal.charAt(charIndex) >= '0'
						&& literal.charAt(charIndex) <= '9')
					dBIndex = 10 * dBIndex
							+ (literal.charAt(charIndex++) - '0');
					
				Leaf leaf = this.leafFactory.newTerm();
				leaf.setDBIndex(dBIndex);
				
				Term term = leaf;
				
				if (termStack[stackIndex] != null) {
					Pair pair = this.pairFactory.newTerm();
					pair.setLeft(termStack[stackIndex]);
					pair.setRight(leaf);
					term = pair;
				}
				termStack[stackIndex] = term;
			}
		}
		
		Term argTerm = termStack[stackIndex];
		if (argTerm == null)
			throw new UncompleteExpressionException(literal);
		
		while (true) {
			int absCount = absCountStack[stackIndex];
			for (int k = 0; k < absCount; k++) {
				Abstraction abstraction = this.abstractionFactory.newTerm();
				abstraction.setBody(argTerm);
				argTerm = abstraction;	
			}
			if (stackIndex == 0)
				break;
			
			termStack[stackIndex] = null;
			absCountStack[stackIndex] = 0;
			stackIndex--;
			
			if (termStack[stackIndex] != null) {
				Pair pair = this.pairFactory.newTerm();
				pair.setLeft(termStack[stackIndex]);
				pair.setRight(argTerm);
				argTerm = pair;
			}
		}
		return argTerm;
	}
	
	private final TermFactory<Abstraction> abstractionFactory;
	private final TermFactory<Pair> pairFactory;
	private final TermFactory<Leaf> leafFactory;

	public ConverterImpl() {
		this.abstractionFactory = TermImpl.termFactories.getAbstractionFactory();
		this.pairFactory = TermImpl.termFactories.getPairFactory();
		this.leafFactory = TermImpl.termFactories.getLeafFactory();
	}
}
