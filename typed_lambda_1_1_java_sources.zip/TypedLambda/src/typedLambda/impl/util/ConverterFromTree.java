package typedLambda.impl.util;

import java.util.ArrayList;
import java.util.List;

import typedLambda.common.Literal;
import typedLambda.model.term.Abstraction;
import typedLambda.model.term.Leaf;
import typedLambda.model.term.Pair;
import typedLambda.model.term.Term;
import typedLambda.model.util.exception.NotInNormalFormException;
import typedLambda.model.util.exception.convert.LoopException;

/*
 * Converter from tree representation to literal representation
 * 	of a lambda expression.
 */
public abstract class ConverterFromTree {
	
	private static final String expression(Term hand,
			List<Abstraction> abstractionList,
			List<Leaf> leafList,
			List<Pair> pairList,
			boolean isRoot, boolean isRight) {
		if (hand.isPair()) {
			Pair pair = (Pair) hand;
			int pairIndex = pairList.indexOf(pair);
			if (pairIndex >= 0)
				throw new LoopException("pair", pairIndex);
			StringBuffer sb = new StringBuffer();
			if (!isRoot && isRight)
				sb.append('(');
			sb.append(expression(pair.getLeft(),
					abstractionList, leafList, pairList, false, false));
			sb.append(expression(pair.getRight(),
					abstractionList, leafList, pairList, false, true));
			if (!isRoot && isRight)
				sb.append(')');
			return sb.toString();
		}
		if (hand.isLeaf()) {
			Leaf leaf = (Leaf) hand;
			int varIndex = leafList.indexOf(leaf);
			if (varIndex >= 0)
				throw new LoopException("leaf", varIndex);
			leafList.add(leaf);
			Abstraction target = leaf.getTarget();
			int absIndex = abstractionList.indexOf(target);
			if (absIndex < 0)
				throw new NotInNormalFormException();
			char absChar = (char) ('a' + absIndex);
			return String.valueOf(absChar);
		}
		throw new NotInNormalFormException();
	}

	/*
	 * This converter takes a tree representation in normal form of a lambda term
	 * 	and returns a classic literal representation of this lambda term.
	 */
	public static final String convertToLiteral(Abstraction  hand)
			throws NotInNormalFormException {
		List<Abstraction> abstractionList = new ArrayList<Abstraction>();
		List<Leaf> leafList = new ArrayList<Leaf>();
		List<Pair> pairList = new ArrayList<Pair>();
		
		Term term = hand;
		
		while (true) {
			Abstraction abstraction = (Abstraction) term;
			int absIndex = abstractionList.indexOf(abstraction);
			if (absIndex >= 0)
				throw new LoopException("abstraction", absIndex);
			abstractionList.add(abstraction);
			term = abstraction.getBody();
			if (!term.isAbstraction())
				break;
		}
		String expression = expression(term, abstractionList, leafList, pairList, true, false);
		return new Literal(abstractionList.size(), expression).toString();
	}
}
